import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.lang.Math.*; // imports math

/**
 * The DarrenChui class represents me and my seating location in AP CSA
 * 
 * @author Darren Chui
 * @version 1.3, 9/10/19
 */
public class DarrenChui extends Student implements SpecialInterestOrHobby
{   
    // number of siblings - brothers and sisters
    int numBrothers = 1;
    int numSisters = 0;
    
    // checks if user wants to learn more
    boolean more;
    // prevents user from infinitely asking more 
    boolean askedMore;
    
    /**
     * Constructor for the DarrenChui class, passes in name and seating location.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     */
    public DarrenChui(String f, String l, int r, int s) {
        numStudents++;
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.png";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
    }
    
    /**
     * Default constructor, stores name and seating location just in case. 
     */
    public DarrenChui() {
        numStudents++;
        firstName="Darren";
        lastName="Chui";
        myRow=1;
        mySeat=4;
        // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
        portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.png";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * Act - do whatever the DarrenChui actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment, but only executes commands when the object is clicked on.
     */   
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                getImage().mirrorHorizontally();
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
                myHobby("I like to play competitive shooter or survival sandbox video games.");
                numberOfSiblings();
                numberOfBrothers();
                numberOfSisters();
                
                circleClass();  // Darren Chui's special method
            }
            else {
                answerQuestion();
                sitDown();
            }   
        }
    } 
    
    /**
     * Prints the first and last name to the terminal.
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName + ".");
    }
    
    /**
     * Method asks user if the actor can sit back down until granted privilege. Allows for different permutations of "yes". Also
     * detects if the user wants to learn more about their previously asked question.
     */

    public void askSitDown(String q) {
        String yes [] = new String [3];
        yes[0] = "yes";
        yes[1] = "sure";
        yes[2] = "yeah";
        boolean sit = false;
        
        //infinite loop that asks user if student can sit down
        sitDownLoop:
        while (sit != true) {
            q=Greenfoot.ask("May I sit down?");
            if (q.contains("more") && askedMore == false) {
                askedMore = true;
                break sitDownLoop;
            }
            
            for (int e = 0; e < 3; e++) {
                if (q.toLowerCase().contains(yes[e])) {
                    Greenfoot.delay(10);
                    sitDown();
                    break sitDownLoop; 
                }
            }
        }
    }
    
    /**
     * This method allows the user to interact with the student through a question and answer interface, and provides
     * a mechanism that allows the student to sit down once the Q&A session ends.
     * Loops through a 2D array with preassigned key words that prompt an answer to the presumed question. 2D array also
     * stores a second answer if needed.
     */
    
    public void answerQuestion(){
        askedMore = false;
        
        int numQuestions = 11;
        
        // 2D array for storing questions and answers
        String questionsArray [][] = new String [3] [numQuestions];
        
        // adds questions and answers to the array
        questionsArray[0][0] = "hard";
        questionsArray[1][0] = "2D arrays, recursion, and merge sort...";
        questionsArray[2][0] = "I find these difficult because there is a lot of data involved, and it is sometimes difficult to visualize...";
        
        questionsArray[0][1] = "video game";
        questionsArray[1][1] = "My favorite video games right now are Apex Legends and Minecraft...";
        questionsArray[2][1] = "I find Apex Legends' gunplay fun while Minecraft is just a chill game...";
        
        questionsArray[0][2] = "old";
        questionsArray[1][2] = "I am 16 years old right now...";
        questionsArray[2][2] = "There really isn't anything else I can say about my age...";
        
        questionsArray[0][3] = "food";
        questionsArray[1][3] = "My favorite food is Dried Scallop and Egg White Fried Rice...";
        questionsArray[2][3] = "I love this dish because it has a lot of wok hei...";
        
        questionsArray[0][4] = "cartoon";
        questionsArray[1][4] = "My favorite cartoon is Avatar: The Last Airbender...";
        questionsArray[2][4] = "It has great character development, plot, and animation...";
        
        questionsArray[0][5] = "minecraft";
        questionsArray[1][5] = "I play Minecraft on the hypixel.net server and the official Dublin High School server owned by Jacob Sommer...";
        questionsArray[2][5] = "I usually play Hypixel for the pvp gameplay while the DHS server is for some chill SMP...";
        
        questionsArray[0][6] = "class";
        questionsArray[1][6] = "I am taking Trig Precalc, AP Chem, AP Lang, APCSA, AP Mandarin, and APUSH as of Junior year 2019-2020...";
        questionsArray[2][6] = "There really isn't anything else I can say about the classes I am taking...";
        
        questionsArray[0][7] = "student";
        questionsArray[1][7] = "There are " + numStudents + " students in this class...";
        questionsArray[2][7] = "There really isn't anything else I can say about the number of students in this class...";
        
        questionsArray[0][8] = "sibling";
        questionsArray[1][8] = "I have " + (numBrothers + numSisters) + " sibling(s)...";
        questionsArray[2][8] = "There really isn't anything else I can say about the number of siblings I have...";
        
        questionsArray[0][9] = "brother";
        questionsArray[1][9] = "I have " + numBrothers + " brother(s)...";
        questionsArray[2][9] = "There really isn't anything else I can say about the number of brothers I have...";
        
        questionsArray[0][10] = "students";
        questionsArray[1][10] = "I have " + numSisters + " sister(s)...";
        questionsArray[2][10] = "There really isn't anything else I can say about the number of sisters I have...";
        
        // asks user what question they have and returns an answer
        String q = Greenfoot.ask("Whew, I somehow made my way out of that isekai... More importantly, what would you like to know?");
        
        // flags whether or not question is in 2d array
        boolean understand = false; 
        
        // flags question row/column
        int qr = 0;
        int qc = 0;
        
        // checks for keywords in questions and flags
        keyWordSearch:
        for (int r = 0; r < questionsArray.length; r++){
            for (int c = 0; c < questionsArray[r].length; c++) {
                if (q.contains(questionsArray[r][c])) {
                    understand = true;
                    qr = r+1;
                    qc = c;
                    break keyWordSearch;
                }
            }
        }
        
        // answers question if possible and asks if actor can sit down
        if (understand == true) {
            q = Greenfoot.ask(questionsArray[qr][qc] + " Press enter to continue.");
            askSitDown(q);
            if (askedMore == true) {
                q = Greenfoot.ask(questionsArray[qr+1][qc] + " Press enter to continue.");
                askSitDown(q);
            }
        }
        else {
            q = Greenfoot.ask("I don't understand the question... Press enter to continue.");
            askedMore = true;
            askSitDown(q);
        }
    }
    

    /**
     * This is a local method specific to the DarrenChui class used to animate the character once the image is clicked on. 
     * Executes for loops for basic animation before looping through a 2D array that generates random coordinates to move
     * object to. Adds a new object into the world called truck.
     */
    public void circleClass(){
        int [][] rdmCoord = new int [1][2];
        int xCoord = 0;
        int yCoord = 0;
        int numAnimation = 0;
        
        setLocation(0,1);
        Greenfoot.delay(10);
        // move right
        for (int i=1;i<=10;i++){
            setLocation(i,1);
            Greenfoot.delay(2);
        }
        
        // move left
        this.getImage().mirrorHorizontally();
        for (int i=10;i>=0;i--){
            setLocation(i,6);
            Greenfoot.delay(2);
        }      

        // move diagonally and rotate
        for (int i=1;i<=6;i++) {
            setLocation(i,i);
            getImage().rotate(360/6);
            Greenfoot.delay(2);
        }
       
        // randomly telport in and out of existence
        for (int i=0;i<32;i++) {
            for (int r = 0; r < rdmCoord.length; r++) {
                for (int c = 0; c < rdmCoord[r].length; c++) {
                    if (c %2 == 0) {
                        rdmCoord[r][c] = (int)(Math.random() * 10);
                        xCoord = rdmCoord[r][c];
                    }
                    else {
                        rdmCoord[r][c] = (int)(Math.random() * 6);
                        yCoord = rdmCoord[r][c];
                    }
                }
            }
            setLocation(xCoord, yCoord);
            getImage().rotate((int)(Math.random() * 360));
            getImage().setTransparency((int)(Math.random() * 255));
            Greenfoot.delay(4);
        }
        returnToSeat();
        
        //animation and spawns truck during animation
        while (numAnimation != 4) {
            for (int frame = 1; frame <= 10; frame++) {
                setImage("naruto-run ("+frame+").png");
                Greenfoot.delay(5);
            } 
            numAnimation++;
            if (numAnimation == 4) {
                truck truck = new truck();
                getWorld().addObject(truck, 10, 1);
            }
        }
    }
   
    /**
     * Prints hobbies in the terminal window
     */
    public void myHobby(String s) {
             System.out.println(s);
    }
    
    /**
     * Prints number of siblings in the terminal window
     */
    public void numberOfSiblings() {
        System.out.println(numBrothers + numSisters);
    }
    
    /**
     * Prints number of siblings in the terminal window
     */
    public void numberOfBrothers() {
        System.out.println("I have " + numBrothers + " brother(s)");
    }
    
    /**
     * Prints number of sisters in the terminal window
     */
    public void numberOfSisters() {
        System.out.println("I have " + numSisters + " sister(s)");
    }
}

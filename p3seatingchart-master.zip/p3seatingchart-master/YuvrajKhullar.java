import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.lang.Math;
import java.util.*;
/**
 * The YuvrajKhullar class does a little animation where the object moves across the screen and bounces off the walls that are randomly spawned throughout the screen.
 * As it does the animation, the name of the student is played before the user can ask the student what concepts he thinks are hard and why. 
 * 
 * @author Yuvraj Khullar
 * @version 1.0 Aug 15, 2019
 */
public class YuvrajKhullar extends Student implements SpecialInterestOrHobby
{
    
    /**
     * Constructor for the YuvrajKhullar class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public YuvrajKhullar(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     */
    public YuvrajKhullar() {
        firstName="Yuvraj";
        lastName="Khullar";
        myRow=2;
        mySeat=1;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
        Student.numStudents += 1;
    }
    
     /**
     * Act - do whatever the KilgoreTrout actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                System.out.println(""); // Print a blank line to create space between any student output.
                setImage(standingFile);
                getName();
                sayName(soundFile);
            
                myHobby("I like to take photos!");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                circleClass();  // Kilgore Trount's special method... Please write one of your own. You can use this, but please modify it and be creative.
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method allows the user to ask the student what concept they think is hard and what exactly they think is hard about that concept in Java. If the allows the student to sit down whne prompted, the environment 
     * becomes like it was at the start of the program.
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know");
        boolean flag = false;
        if (q.contains("hard")){
            while(flag == false) {
                q=Greenfoot.ask("Insertion, 2D arrays, Overloaded methods, Abstract classes, and Interfaces... What would you like to know about or may I sit down?");
                if (q.contains("Insertion")) {
                    q=Greenfoot.ask("Inserting items into an insertion sort is hard to do... May I sit down?");
                    if (q.equals("yes")){
                        Greenfoot.delay(10);
                        sitDown();
                        break;
                    } else if (q.equals("no") || q.equals("No") || q.equals("NO")) {
                        Greenfoot.delay(10);
                    }
                } else if (q.contains("arrays")) {
                    q=Greenfoot.ask("It is confusing to assign values to 2D arrays and it can be hard to track all values in the array... May I sit down?");
                    if (q.equals("yes")){
                        Greenfoot.delay(10);
                        sitDown();
                        break;
                    } else if (q.equals("no") || q.equals("No") || q.equals("NO")) {
                        Greenfoot.delay(10);
                    }
                } else if (q.contains("methods")) {
                    q=Greenfoot.ask("Overloading methods can be hard to keep track of since a method with the same name can be doing something that I don't intend it to do... May I sit down?");
                    if (q.equals("yes")){
                        Greenfoot.delay(10);
                        sitDown();
                        break;
                    } else if (q.equals("no") || q.equals("No") || q.equals("NO")) {
                        Greenfoot.delay(10);
                    }
                } else if (q.contains("classes")) {
                    q=Greenfoot.ask("Abstract classes are confusing to use while making programs... May I sit down?");
                    if (q.equals("yes")){
                        Greenfoot.delay(10);
                        sitDown();
                        break;
                    } else if (q.equals("no") || q.equals("No") || q.equals("NO")) {
                        Greenfoot.delay(10);
                    }
                } else if (q.contains("Interfaces") || q.contains("interfaces")) {
                    q=Greenfoot.ask("It is hard to define and implement interfaces into a program... May I sit down?");
                    if (q.equals("yes")){
                        Greenfoot.delay(10);
                        sitDown();
                        break;
                    } else if (q.equals("no") || q.equals("No") || q.equals("NO")) {
                        Greenfoot.delay(10);
                    }
                } else {
                    q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
                    if (q.equals("yes")){
                        Greenfoot.delay(10);
                        sitDown();
                        break;
                    } else if (q.equals("no") || q.equals("No") || q.equals("NO")) {
                        Greenfoot.delay(10);
                        
                    }
                  }
            }
        } 
        else if (q.contains("number")) {
            q = Greenfoot.ask("Our class has " + Student.numStudents + " students... May I sit down?");
            if (q.equals("yes")){
                Greenfoot.delay(10);
                sitDown();
            } else  {
                Greenfoot.delay(10);
                answerQuestion();
            }
        }
        else {
            q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            if (q.equals("yes")){
                Greenfoot.delay(10);
                getWorld().removeObjects(getWorld().getObjects(dust.class));
                sitDown();
            } else  {
                Greenfoot.delay(10);
                answerQuestion();
            }
        }
         
        
    }
    /**
     * This is a local method specific to the YuvrajKhullar class used to animate the character once the image is clicked on. The animation makes the standing image spawn walls on random coordinates on the screen 
     * using a 2D array and then has the object move across the screen, bouncing off the walls and the ends of the screen, leaving a trail of dust behind. 
     */
    public void circleClass(){
        setLocation(0,0);
        Greenfoot.delay(10);
        int num = 1;
        int x = 0;
        int y = 0;
        int dx = 1;
        int dy = 1;
        int[][] array = new int[10][6];
         for (int i = 0;i < 8; i++) {
            num = (int)(8.0 * Math.random());
            if (num > 3) {
                for (int row = 0; row < array.length - 1; row++) {
                    for (int col = 0; col < array[row].length; col++) {
                        if (col % 2 == 0) {
                            array[row][col] = Greenfoot.getRandomNumber(10);
                            if(array[row][col] != array[1][2] && array[row][col] != 0 && array[row][col] != 9)
                                x = array[row][col];
                        }
                        else {
                            array[row][col] = Greenfoot.getRandomNumber(6);
                            if(array[row][col] != array[1][2] && array[row][col] != 0 && array[row][col] != 5)
                                y = array[row][col];
                        }
                    }
                }
                Wall wall = new Wall();
                getWorld().addObject(wall, x, y);
            }
            Greenfoot.delay(10);
            
        }
            
        while (true){
            setLocation(getX() + dx, getY());
            Greenfoot.delay(10);
            if (getX() == 9) {
                setLocation(getX(), getY() + 1);
                dx = -dx;
            }
            if (getY() != 0 && getX() == 0) {
                setLocation(getX(), getY() + 1);
                dx = -dx;
            }
            if (isTouching(Wall.class)) {
                setLocation(getX(), getY() + 1);
                dx = -dx;
            }
            if (getY() == 5 && getX() == 9) {
                getWorld().removeObjects(getWorld().getObjects(Wall.class));
                returnToSeat();
                break;
            }
            if(getX() != 1 && getY() != 2) {
                dust img = new dust();
                getWorld().addObject(img, getX(), getY());
            }
            
        }
    }
    
    public void myHobby(String s) {
         System.out.println(s);
    }

}

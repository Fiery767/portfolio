import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Actor spawned only by the an object of the DarrenChui class. Part of the DarrenChui
 * circleClass method for the animatoin. 
 * 
 * @author Darren Chui
 * @version 1.3, 9/10/19
 */
public class truck extends Actor
{
    /**
     * Act - do whatever the truck wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * If DarrenChui object is run over by truck object while moving via for loop, DarrenChui vanishes while the truck plays its sound files. 
     * Once the truck reaches the left of the classroom, it removes itself from the world.
     */
    public void act() 
    {
        String truckImage = "truck.png";
        setImage(truckImage);
        
        Greenfoot.playSound("truck.wav");
        Greenfoot.playSound("truckMusic.wav");
        setLocation(10, 1);
        for (int i = 10; i >= 0; i--) {
            if (touchTruck()) {
                Greenfoot.playSound("bonk.wav");
                Greenfoot.playSound("oof.wav");
                transportStudent();
            }
            setLocation(i, 1);
            Greenfoot.delay(3);
            if (i == 0) {
                despawnTruck();
            }
        }
    }    
    
    /** Checks to see if the truck collides with the Darren Chui object
     */
    
    private boolean touchTruck() {
        Actor Darren = getOneObjectAtOffset(0, 0, DarrenChui.class);
        if(Darren != null) {
            return true;
        }
        else {
            return false;
        }
    }
    
    /** Makes the Darren Chui object disappear 
     */
    private void transportStudent() {
        Actor Darren = getOneObjectAtOffset(0, 0, DarrenChui.class);
        if(Darren != null) {
            getWorld().getObjects(Actor.class).get(1).getImage().setTransparency(0);
        }
    }
    
    /** Removes the truck and makes all objects return
     */
    private void despawnTruck() {
        this.getImage().setTransparency(0);
        Greenfoot.delay(100);
        getWorld().getObjects(Actor.class).get(1).getImage().setTransparency(255);
        getWorld().removeObject(this);
    }
}

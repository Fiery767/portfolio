import java.util.*;
import greenfoot.*;
import java.util.ArrayList;
import java.lang.Math;
   // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * @author Mingye Wang
 * @version 2.0 Aug 13, 2019
 */
public class WangMingye extends Student implements SpecialInterestOrHobby
{
    public String img;
    int[][] location = new int[9][2];
    
    /**
     * Constructor for the WangMingye class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public WangMingye(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        
        scale(portraitFile, 100, 125);
        sitting=true;
        randLocation();
        numStudents++;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     */
    public WangMingye() {
        firstName="Mingye";
        lastName="Wang";
        myRow=5;
        mySeat=4;
        // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
        portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        
        scale(portraitFile, 100, 125);
        sitting=true;
        randLocation();
        numStudents++;
    }
     /**
     * Act - do whatever the WangMingye actor needs to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */   
    public void act() 
    {
        // Add your action code here.
        scale(portraitFile, 100, 125);
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
             sitting = false;
             scale(standingFile, 125, 150);
             
             load_staff();
             
             System.out.println(""); // Print a blank line to create space between any student output.
             getName();
            
             myHobby("I like to practice");
            
             // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
             // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
             // Call the sitDown() method to move back  to your seat
             
             Greenfoot.playSound("paganini.wav");
             circleClass();
             animation();
             load_out_staff();
             
             
             }
            else {
                answerQuestion();
                sitDown();
                scale(portraitFile, 100, 125);
            }
        }
    } 
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     * There are tiers of questions, using booleans to determine whether or not to advance the level of depth in the questions.
     */
    public void answerQuestion(){
        boolean hard_continue = false;
        boolean practice_continue = false;
        boolean violin_continue = false;
        boolean violin_continue2 = false;
        boolean math_continue = false;
        boolean shine_continue = false;
        String q=Greenfoot.ask("What would you like to know");
        //first tier of questions
        if (q.contains("hard")){
            q=Greenfoot.ask("2D arrays, recursion... Not much really, I'm a C++ guy.");
            hard_continue = true;
        }
        else if (q.contains("practice")){
            q=Greenfoot.ask("I practice 40 hours a day...");
            practice_continue = true;
        }
        else if (q.contains("violin")){
            q=Greenfoot.ask("I've been playing for 10 years... But Ling Ling plays better than me, that's all I can say.");
            violin_continue = true;
        }
        else if (q.contains("math")){
            q=Greenfoot.ask("I can tell you that I do math well enough to do the AMC.");
            math_continue = true;
        }
        else if (q.contains("shine"))
        {
            q=Greenfoot.ask("I can shine. Do you want me to do it?");
            shine_continue = true;
        }
        else 
        {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
        if (hard_continue) //second tier of CSA questions
        {
            if (q.contains("2D arrays"))
            {
                q=Greenfoot.ask("I think 2D arrays are hard that it's sometimes hard to figure out use cases and how the programs cycle through them... May I sit now?");
            }
            else if (q.contains("recursion"))
            {
                q=Greenfoot.ask("I think recursion is hard in that you have to write out what the program is printing in terms of output. There's a lot of writing involved to be able to figure out a recursive function. May I sit now?");
            }
            else {
                q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            }
        }
        if (practice_continue) //second tier of practice questions
        {
            if (q.contains("how"))
            {
                q=Greenfoot.ask("I can't tell you... that's Ling Ling's secret. May I sit?");
            }
            else if (q.contains("like"))
            {
                q=Greenfoot.ask("Yes, I love to practice... I need to practice. May I sit down so I may practice?");
            }
            else {
                q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            }
        }
        if (violin_continue) //second tier of violin questions
        { 
            if (q.contains("hard"))
            {
                q=Greenfoot.ask("I haven't learned all the techniques. However I do need to practice my up-bow staccato, chromatic glissando, left-hand pizzicato, and artificial harmonics.");
                violin_continue2 = true;
            }
            else if (q.contains("Ling Ling"))
            {
                q=Greenfoot.ask("Ling Ling practice 40 hours a day. My role model. May I sit?");
            }
            else {
                q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            }
        }
        if (math_continue) //second tier of math questions
        {
            if (q.contains("hard"))
            {
                q=Greenfoot.ask("I'm really bad at probability and number theory. May I sit?");
            }
            else if (q.contains("favorite"))
            {
                q=Greenfoot.ask("My favorite math subject to do is trigonometry. May I sit?");
            }
            else {
                q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            }
        }
        if (shine_continue) //allows for demonstrating the potential of shine
        {
            if (q.contains("yes"))
            {
                Greenfoot.delay(10);
                shine();
                q=Greenfoot.ask("Do you want me to do it again?");
                while (true)
                {
                    if (q.contains("no"))
                    {
                        q=Greenfoot.ask("Alright. May I sit?");
                        break;
                    }
                    else if (q.contains("yes"))
                    {   
                        System.out.println("Alright");
                        Greenfoot.delay(10);
                        shine();
                        Greenfoot.playSound("shine.wav");
                        q=Greenfoot.ask("Do you want me to do it again?");
                    }
                    else if (q.contains("multishine"))
                    {   
                        System.out.println("Alright");
                        int preg= Integer.parseInt(Greenfoot.ask("How many times? Please enter an integer value."));
                        Greenfoot.delay(10);
                        for (int i = 0; i < preg; i++)
                        {
                            shine();
                            Greenfoot.playSound("shine.wav");
                            Greenfoot.delay(1);
                        }
                        q=Greenfoot.ask("Do you want me to do it again?");
                    }
                    else
                    {
                        System.out.println("I don't understand... Guess I'll do it again.");
                        Greenfoot.delay(10);
                        shine();
                        Greenfoot.playSound("shine.wav");
                        q=Greenfoot.ask("Do you want me to do it again?");
                    }
                }
            }
            else
            {
                q=Greenfoot.ask("Alright... May I sit down?"); 
            }
        }
        if (violin_continue2) //third tier of violin questions
        {
            if (q.contains("staccato"))
            {
                q=Greenfoot.ask("I have trouble getting consistency in sound because I can't press very well. May I sit?");
            }
            else if (q.contains("gliss"))
            {
                q=Greenfoot.ask("The notes are high and I have trouble dragging my finger down the string. May I sit?");
            }
            else if (q.contains("pizz"))
            {
                q=Greenfoot.ask("I have trouble plucking some of the notes, especially in Paganini Caprice No. 24. May I sit?");
            }
            else if (q.contains("harmonics"))
            {
                q=Greenfoot.ask("It's hard to play in tune, the intervals must be perfect and the bow contact has to be good. May I sit?");
            }
            else {
                q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            }
        }
        while (true) //will not sit until a "yes" is given
        {
            if (q.equals("yes")){
                Greenfoot.delay(10);
                sitDown();
                break;
            }
            else
            {
                q=Greenfoot.ask("I will not sit down until you give me an affirmative \"yes\"... May I sit down?");  
            }
        }   
        scale(portraitFile, 100, 125);
    }
    /**
     * This is a local method specific to the WangMingye class used to animate the character once the image is clicked on.
     * You can write your own methods to perform your own animation for your character/avatar.
     * This animation attempts to play Paganini Caprice No. 24 on a spawned staff, the movement is scripted.
     */
    public void circleClass(){
        Greenfoot.delay(80);
        for (int i = 0; i < 2; i++)
        {
            setLocation(2,3);
            Greenfoot.delay(23);
            setLocation(3,3);
            Greenfoot.delay(7);
            setLocation(4,3);
            Greenfoot.delay(8);
            setLocation(5,2);
            Greenfoot.delay(8);
            setLocation(6,3);
            Greenfoot.delay(7);
            setLocation(7,4);
            Greenfoot.delay(7);
            setLocation(2,1);
            Greenfoot.delay(23);
            setLocation(3,5);
            Greenfoot.delay(7);
            setLocation(4,5);
            Greenfoot.delay(8);
            setLocation(5,3);
            Greenfoot.delay(7);
            setLocation(6,4);
            Greenfoot.delay(8);
            setLocation(7,5);
            Greenfoot.delay(7);
            setLocation(2,3);
            Greenfoot.delay(22);
            setLocation(3,3);
            Greenfoot.delay(8);
            setLocation(4,3);
            Greenfoot.delay(8);
            setLocation(5,2);
            Greenfoot.delay(7);
            setLocation(6,3);
            Greenfoot.delay(8);
            setLocation(7,4);
            Greenfoot.delay(7);
            setLocation(3,1);
            Greenfoot.delay(32);
            setLocation(6,5);
            Greenfoot.delay(32);
        }
    }
    /**
     * The second half of the animation
     * The first block has my picture spin rapidly while my name file plays
     * The second block has me multi-shining in the random locations determined by the random location function
     */
    public void animation()
    {
        setLocation((int)(10 * Math.random()), (int)(6 * Math.random()));
        scale(standingFile, 400, 500);
        sayName(soundFile);
        for (int i = 0; i <= 900; i += 10)
        {
            setRotation(30*i);
            Greenfoot.delay(1);
        }
        scale(standingFile, 125, 150);
        for (int i = 0; i < location.length; i++)
        {
            int j = 0;
            setLocation(location[i][j], location[i][j+1]);
            Greenfoot.delay(1);
            Greenfoot.playSound("shine.wav");
            shine();
            Greenfoot.delay(1);
        }
        returnToSeat();
    }
    public void myHobby(String s) {
         System.out.println(s);
    }
    /**
     * A local method that constantly updates the size of the image so that it is scaled appropriately
     */
    public void scale(String input, int w, int h)
    {
        GreenfootImage img = new GreenfootImage(input);
        img.scale(w, h);
        setImage(img);
    }
    /**
     * A local method that loads in the staff when it is time to practice Paganini
     */
    public void load_staff()
    {
        Classroom classroom = (Classroom) getWorld();
        staff staff = new staff();
        classroom.addObject(staff, 6, 3);
        classroom.setPaintOrder(WangMingye.class,staff.class);
    }
    /**
     * A local method that loads the staff out of existence when the practice is finished
     */
    public void load_out_staff()
    {
        Classroom classroom = (Classroom) getWorld();
        List remove = classroom.getObjects( staff.class );
        for (Object objects : remove) {
                classroom.removeObject( ( staff ) objects ); }
    }
    /**
     * A local method that uses a 2D array to determine random locations that will be used for multi-shining
     * The first block assigns random values to each array index from 0 to 255
     * The second block uses modular arithmetic so that the randomly generated numbers fall within the class dimensions
     */
    public void randLocation()
    {
        for (int i = 0; i < location.length; i++)
        {
            for (int j = 0; j < location[i].length; j++)
            {
                location[i][j] = (int)(Math.random() *  255);
            }
        }
        for (int i = 0; i < location.length; i++)
        {
            int j = 0;
            location[i][j] = location[i][j] % 11; //sets the random x-positions
            location[i][j + 1] = location[i][j] % 7; //sets the random y-positions
        }
    }
    /**
     * A local method that makes the actor perform a Down-B shine
     */
    public void shine()
    {
        Classroom classroom = (Classroom) getWorld();
        shine shine = new shine();
        classroom.addObject(shine, getX(), getY());
        classroom.setPaintOrder(shine.class,WangMingye.class);
        Greenfoot.delay(3);
        List remove = classroom.getObjects( shine.class );
        for (Object objects : remove) {
                classroom.removeObject( ( shine ) objects ); }
        Greenfoot.delay(5);
    }
}
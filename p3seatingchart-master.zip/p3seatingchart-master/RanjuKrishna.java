import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * @author Ranju Krishna
 * @version 1.0 9/1/19
 */
public class RanjuKrishna extends Student implements SpecialInterestOrHobby, NumberOfSiblings
{
private int numBrothers = 0;
private int numSisters = 1;
    /**
     * Constructor for the RanjuKrishna class. 
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     * 
     * Sets name, row, seat, and sound & image files.
     * Increments student counter.
     *@param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public RanjuKrishna(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        numStudents++; 
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location.
     * Sets image at the location of 1,1 in the world.
     */
    public RanjuKrishna() {
        firstName="Ranju";
        lastName="Krishna";
        myRow=2;
        mySeat=2;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * Act - do whatever the RanjuKrishna actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * States name and sets standing image. Plays sound that says name. 
     * 
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I play guitar!");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                runaround();  // Kilgore Trount's special method... Please write one of your own. You can use this, but please modify it and be creative.
            }
            else {
                answerQuestion();
                
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console.
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  
     * Initiates dialogue session that answers questions using conditional statements such as what was hard in the summer homework and how many students in the class.
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know");
        if (q.contains("hard")){
            q=Greenfoot.ask("Recursion, overloaded methods, arraylist, wrapper classes, and tracing code... May I sit down?");
        
        }
        else if (q.contains("arraylist")){
            q=Greenfoot.ask("Arraylists were very difficult for me to grasp when doing the lessons. I got what the end result was supposed to be, but I can never understand how to implement it into the code. I still don't really understand but I am sure I will learn it soon... may I sit down?");
        }
        else if (q.contains("how many students")){
            q=Greenfoot.ask(numStudents + "...may I sit down?");
        }
        else if (q.contains("how many siblings")){
            q=Greenfoot.ask("1...may I sit down?");
        }
        else if (q.equals("yes")){
            Greenfoot.delay(10);
            sitDown();
        }
        else {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
        
    }
    
    /**
     * variable that populates 10 by 2 array that generates random coordinates based on the command Math.random. 
     */
    private int[][] getCoordinates() {
   	 int[][] coords = new int[10][2];

   	 //System.out.println("Size of coords:" + coords.length + " ** " + coords[0].length);

   	 for (short i=0; i < coords.length; i++) {
   		 for (short j = 0; j < coords[i].length; j++) {
   			 coords[i][j] = (int) (Math.random() * 10);
   			 System.out.println(coords[i][j] + ',');
   		 }
   		 //System.out.println(" **");
   	 }
   	 return coords;

    }
    
    
    /**
     * Local method specific to the RanjuKrishna class used to animate the character once the image is clicked on.
     * Initiates method that moves around image based on coordinates generated previously. 
     * returns to seat when finished.
     */
    public void runaround(){
        
        int[][] coordsArr;
        setLocation(0,0);
        Greenfoot.delay(10);
         
         
        // move right
        /*for (int i=1;i<=5;i++){
            setLocation(0,i);
            Greenfoot.delay(100);
        }
        */
        
      coordsArr = getCoordinates();
       
       //Iterate and move the object
       for (short i=0; i < coordsArr.length; i++) {
             System.out.println("x = " + coordsArr[i][0] + " y = " + coordsArr[i][1]);
             setLocation(coordsArr[i][0], coordsArr[i][1]);
             Greenfoot.delay(300);
       }
   
        /*
        // move back
        for (int i=1;i<=5;i++){
            setLocation(9,i);
            Greenfoot.delay(10);
        }      
         // move left
        for (int i=9;i>=0;i--){
            setLocation(i,5);
            Greenfoot.delay(10);
        }      
              // move Forward
        for (int i=5;i>=0;i--){
            setLocation(0,i);
            Greenfoot.delay(10);
        } 
        */
           Greenfoot.delay(20);
           returnToSeat();
    }
    /** 
     * generates response for my hobbies. 
     */ 
    public void myHobby(String s) {
         System.out.println(s);
}
/**
 * answers how many siblings when asked in dialogue session
 */
public int numberOfSiblings() {
    return 1;
}
/** 
 * answers how many brothers when asked in dialogue session
 */
public int numberOfBrothers() {
    return 0;
}
/** 
 * answers how many sisters when asked in dialogue session
 */
public int numberOfSisters() {
    return 1;
}
}
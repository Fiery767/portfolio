
import greenfoot.*; // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;
/**
 * The JeffCheema class represents Jeff Cheema in 3rd period CSA in his assgned seat. 
 * 
 * @author Mr. Kaehms
 * @version 2.0 Aug 13, 2019
 */
public class JeffCheema extends Student implements SpecialInterestOrHobby {
     /**
     * The Question Running variable dictates whether the Q and A system will run based on whether the user let's the student sit down or not. 
     */
 boolean QuestionsRunning = true;
 /**
  * Constructor for the JeffCheema class.
  * Constructors are special methods with the same exact name as the class name.  
  * Constructors to not have return types.
  * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
  *  lists to initalize for different conditions (depending on what constructors have been written.
  * @param String f (firstname)
  * @param String l (lastname)
  * @param int r (row of seating arrangement)
  * @param int s (seat number within row seating arrangement)
  * 
  */
 
 public JeffCheema(String f, String l, int r, int s) {
  firstName = f;
  lastName = l;
  myRow = r;
  mySeat = s;
  portraitFile = f.toLowerCase() + l.toLowerCase() + ".jpg"; // Make sure to name your image files firstlast.jpg, all lowercase!!!
  standingFile = firstName.toLowerCase() + lastName.toLowerCase() + "-standing.jpg";
  soundFile = f.toLowerCase() + l.toLowerCase() + ".wav"; // Make sure to name your sound files firstlast.wav, all lowercase!!!
  setImage(portraitFile);
  sitting = true;
  numStudents++;
 }
 /**
  * Default constructor, if you don't pass in a name and seating location
  * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
  * of the classroom.
  * This sets up the class file is the initial constructer is not set up properly, a back up of sorts. It also adds +1 to numStudents within the Student class. 
  */
 public JeffCheema() {
  firstName = "Jeff";
  lastName = "Cheema";
  myRow = 1;
  mySeat = 1;

  portraitFile = firstName.toLowerCase() + lastName.toLowerCase() + ".jpg";
  standingFile = firstName.toLowerCase() + lastName.toLowerCase() + "-standing.jpg";
  soundFile = firstName.toLowerCase() + lastName.toLowerCase() + ".wav";
  setImage(portraitFile);
  sitting = true;
  Student.numStudents += 1;
 }

 /**
  * Act - do whatever the JeffCheema actor wants to do. This method is called whenever
  * the 'Act' or 'Run' button gets pressed in the environment.
  */
 public void act() {
  // Add your action code here.
  if (Greenfoot.mouseClicked(this)) {
   if (sitting) {
    sitting = false;
    setImage(standingFile);
    System.out.println(""); // Print a blank line to create space between any student output.
    getName();
    sayName(soundFile);

    myHobby("I like to time travel!");
    // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
    // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
    // Call the sitDown() method to move back  to your seat

    special(); // Kilgore Trount's special method... Please write one of your own. You can use this, but please modify it and be creative.
   } else {
    answerQuestion();
    sitDown();
   }

  }
 }

 /**
  * Prints the first and last name to the console
  */
 public void getName() {
  System.out.println("My name is " + firstName + " " + lastName);
 }
 /**
  * This function asks the user if the student can sit down or not. The understand boolean when set false will mention that the student does not understand. 
  */
 public boolean canSit(boolean understand) {
  String a;
  if (!understand) {
   a = Greenfoot.ask("I don't understand the question... May I sit down?");
  } else {
   a = Greenfoot.ask("May I sit down?");
  }


  if (a.contains("ye")) {
   QuestionsRunning = false;
   return true;

  } else {
      canSit(understand);
   return false;
  }
 }
 /**
  * This method needs to allow the user to interact with the student through a question and answer interface, and provide
  * some mechanism that allows the student to sit down once the Q&A session ends.  You can ask about what was hard about the summer homework and then 
  * Jeff will respond with more specific answer. If Jeff answers your question or cannot answer he will ask to sit down and keep asking until he sits down. 
 
  */
 public void answerQuestion() {


  QuestionsRunning = true;
 
  while (QuestionsRunning) {
   String q = Greenfoot.ask("What would you like to know about ?");
   q = q.toLowerCase();
   q.replaceAll("\\p{Punct}", "");

   if (q.contains("what") && q.contains("summer") && (q.contains("hard") || q.contains("difficult"))) {
    q = Greenfoot.ask("I personally find 2D arrays, sorting algorithms, code tracing, classes, and class inheritance all very difficult to understand. Anything in specific you would like to know?");

    if (q.contains("array")) {
     q = Greenfoot.ask("2D arrays are difficult to conceptualize and hard to keep track of. (press enter to continue)");
     canSit(true);

    } else if (q.contains("sorting") && q.contains("algorithm")) {
     q = Greenfoot.ask("There are too many different types of algorithms and some of them are hard to understand. (press enter to continue)");
     canSit(true);
    } else if (q.contains("code") && q.contains("tracing")) {
     q = Greenfoot.ask("When code tracing it is very easy to make an easy mistake.  (press enter to continue)");
     canSit(true);

    } else if (q.contains("inheritance")) {
     q = Greenfoot.ask("Inheritance can get confusing for me when there are many classes and subclasses.  (press enter to continue)");
     canSit(true);

    } else if (q.contains("classes")) {
     q = Greenfoot.ask("It is hard to remember how to properly initilize classes. (press enter to continue) ");
     canSit(true);
    } else {
     canSit(false);
    }
   } else if (q.contains("number")) {
    q = Greenfoot.ask("Our class has " + Student.numStudents + " students. (press enter to continue)");
    canSit(true);

   } else {
    canSit(false);
   }
  }
 }



 /**
  * This is a local method specific to the JeffCheema class used to animate the character once the image is clicked on.
  * Once the image is clicked the location is set to (0,0) and 20 to 30 points are randomly generated using Math.random and stored in a 2D array. 
  * Then the program will iterate through the 2D array and go to each point and turn the image by 360 divided by # of point degrees to make a full rotation. 
  * At the end the avatar returns to the seat. 
  */
 public void special() {
  setLocation(0, 0);
  Greenfoot.delay(10);
  int random = (int)(Math.random() * 20 + 1) + 30;
  int[][] positions = new int[random][2];
  for (int i = 0; i < positions.length; i++) {
   positions[i][0] = (int)(Math.random() * 6 + 1);
   positions[i][1] = (int)(Math.random() * 10 + 1);
  }

  for (int i = 0; i < positions.length; i++) {
   turn(360 / (positions.length));
   setLocation(positions[i][0], positions[i][1]);
   System.out.println(positions[i][0] + ", " + positions[i][1]);
   Greenfoot.delay(1);

  }
  setRotation(0);
  returnToSeat();


 }
      /**
     * Returns the number of sisters
   
     */
     public int numberOfSiblings() {
        return numberOfBrothers() + numberOfSisters();
    }
    
     /**
     * Returns the number of brothers
   
     */
    public int numberOfBrothers() {
        return 2;
    }
    
     /**
     * Returns the number of sisters
  
     */
    public int numberOfSisters() {
        return 0;
    }
 public void myHobby(String s) {
  System.out.println(s);
 }

}

  
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import java.util.Random;
/**
 *
 * 
 * @author Aarush Aitha, CSA Per. 3
 * @version 2.0 Aug 16, 2019
 */
public class AarushAitha extends Student implements SpecialInterestOrHobby
{

    /**
     * Constructor for the AarushAitha class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public AarushAitha(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     */
    public AarushAitha() {
       firstName="Aarush";
       lastName="Aitha";
       myRow=1;
       mySeat=1;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
       soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
       setImage(portraitFile);
       sitting=true;
    }
     /**
     * Act - do whatever the AarushAitha actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * The Act function will make my Actor stand up when clicked, as well as set
     * the image to standing. It will also print my name and my SpecialInterestOrHobby
     * to the console, as well as say my name once.
     * This method will also run my special animation class, awesomeClass().
     * If it is clicked again, it will run the answerQuestion() method and then
     * sit down.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
            sitting=false;
            setImage(standingFile);
            System.out.println(""); // Print a blank line to create space between any student output.
            getName();
            sayName(soundFile);
            
                myHobby("I am omnipresent. To return the world \n to its regular state, click on \n my standing image and ask \n some questions about me.");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                awesomeClass();  // Aarush Aitha's special method
            }
            else {
                answerQuestion();
                sitDown();
            }      
        }
    } 
    /**
     * This function is a multi-stage Q & A series of while loops and if/else statements
     * It will respond first to a question about the difficulty of the summer homework.
     * If the statement does not detect the word "hard" or "students", it will not understand and prompt
     * you to ask again.
     * Then, the function will give a response with 4 hard subjects from the summer homework
     * The user can then ask specifically about one of the four listed topics (in depth questions)
     * Once the user asks about summer HW and a specific topic, the Actor will repeatedly
     * ask to sit down until the user says "yes".
     */
    public void firstQuestion(boolean flag, String q){
        while (flag)
        {
            if (q.contains("hard")){
                q=Greenfoot.ask("2D arrays, recursion, merge sort, insertion sort. Press enter to continue...");
                boolean flag2 = true;
                while (flag2) {
                    q = Greenfoot.ask("Ask me a question about 2D arrays, recursion, merge sort, or insertion sort");
                    if (q.contains("2D arrays")){
                        q = Greenfoot.ask("It's hard to keep track of the lengths and values in 2D arrays. Press enter to continue...");
                        flag2 = false;
                        break;
                    }
                    if (q.contains("recursion")){
                        q = Greenfoot.ask("The reversal of the results always confuses me when I'm using recursion. Press enter to continue...");
                        flag2 = false;
                        break;
                    }
                    if (q.contains("merge")){
                        q = Greenfoot.ask("It's hard for me to trace the iterations of a merge sort. Press enter to continue...");
                        flag2 = false;
                        break;
                    }
                    if (q.contains("insertion")){
                        q = Greenfoot.ask("It's difficult to insert items in a list for insertion sort. Press enter to continue...");
                        flag2 = false;
                        break;
                    }
                    else {
                        q = Greenfoot.ask("I don't understand...Press enter to continue...");
                    }
                }
                flag = false;
            }
            else if (q.contains("students"))
            {
                q=Greenfoot.ask("There are " + numStudents + " students in this class. Press enter to continue...");
                flag = false;
                break;
            }
            else {
                q=Greenfoot.ask("I don't understand the question! What would you like to know?"); 
            }
        }
    }
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     */
    
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know?");
        boolean flag = true;
        firstQuestion(flag, q);
        flag = true;
        while (flag){
            if (q.equals("yes")){
                sitDown();
                flag = false;
            }
            else {
                q=Greenfoot.ask("May I sit down?");
            }
        }
        Greenfoot.setWorld(new Classroom());
    }
    /**
     * This function will first create a 2D array with 50 randomized coordinates. Then, 
     * the function will iterate through this 2D array and teleport to each of the 50 points with a small delay between 
     * each teleportation. While teleporting, the image will turn to a random angle and also turn into a circular shape
     * 
     * After the teleportation sequence, the function will replace the image of every other actor with my
     * sitting image, and then repeat my name 6 times with a small delay between each iteration.
     * 
     * After all the animations and questions have been answered, the function will return the world to its original
     * state and return my Actor to my proper seat.
     */
    public void awesomeClass(){
        setLocation(0,0);
        Greenfoot.delay(10);
        // move right
        int[][] coords = new int[50][2];
        for (int row = 0; row < coords.length; row++) {
            for (int col = 0; col < coords[row].length; col++) {
                if (col == 0){
                    coords[row][col] = (int)(Math.random() * 9 + 1);
                }
                if (col == 1){
                    coords[row][col] = (int)(Math.random() * 5 + 1);
                }
            }
        }
        for (int row = 0; row < coords.length; row++) {
            setLocation(coords[row][0], coords[row][1]);
            getImage().rotate((int)(Math.random() * 360 + 1));
            Greenfoot.delay(1);
        }
        if (!getWorld().getObjects(Student.class).isEmpty())
        {
            for (Object image : getWorld().getObjects(Student.class))
            {
                ((Student) image).setImage("aarushaitha.jpg"); 
            }
        }
        for (int i = 0; i < 6; i++)
        {
            sayName(soundFile);
            Greenfoot.delay(65);
        }
        setImage(standingFile);
        Greenfoot.delay(2);
        returnToSeat();
    }
    public void myHobby(String s) {
         System.out.println(s);
    }
}
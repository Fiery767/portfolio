import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;

/**
 * Jacob Sommer's class
 * 
 * @author Jacob Sommer
 * @version 2019-09-11
 */
public class JacobSommer extends Student implements SpecialInterestOrHobby, NumberOfSiblings
{
    
    /**
     * Number of brothers represented as an integer
     */
    private int numBrothers = 1;
    
    /**
     * Number of sisters represented as an integer
     */
    private int numSisters = 0;
    
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     * 
     * Sets name, row, seat, and sound & image files
     * Increments student counter
     */
    public JacobSommer() {
       firstName = "Jacob";
       lastName = "Sommer";
       myRow = 4;
       mySeat = 1;
       portraitFile = firstName.toLowerCase() + lastName.toLowerCase() + ".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
       soundFile = firstName.toLowerCase() + lastName.toLowerCase() + ".wav";
       setImage(portraitFile);
       sitting = true;
       numStudents++;
    }
    
    /**
     * Act - do whatever the Jacob wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * 
     * States name.
     * Stands up and runs my special method to teleport around the room and play loud error sounds.
     * Sits down and prompts for questions.
     */
    public void act() {
        // Add your action code here.
        if (Greenfoot.mouseClicked(this)){
            if (sitting) {
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
            
                myHobby("I like to code!");
                // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
                // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
                // Call the sitDown() method to move back  to your seat
                special();
            } else {
                answerQuestion();
                sitDown();
            }
                    
        }
    }
    
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     * 
     * Provides answers for an assortment of different questions differentiated using conditionals.
     */
    public void answerQuestion() {
        String q = Greenfoot.ask("What would you like to know?");
        if (q.contains("sort")) {
            q = Greenfoot.ask("It is difficult to grasp how the algorithm works and figure out how to write it... May I sit down?");
        } else if (q.contains("array")) {
            q = Greenfoot.ask("It is difficult to grasp how data is stored in a 2D array... May I sit down?");
        } else if (q.contains("hard") || q.contains("challenging")) {
            q = Greenfoot.ask("Merge sort, binary sort, 2D arrays, and insertion sort... May I sit down?");
        } else if (q.contains("brother") && q.contains("sister")) {
            q = Greenfoot.ask("I have " + numberOfBrothers() + " brother(s) and " + numberOfSisters() + " sister(s)... May I sit down?");
        } else if (q.contains("brother")) {
            q = Greenfoot.ask("I have " + numberOfBrothers() + " brother(s)... May I sit down?");
        } else if (q.contains("sister")) {
            q = Greenfoot.ask("I have " + numberOfSisters() + " sister(s)... May I sit down?");
        } else if (q.contains("sibling")) {
            q = Greenfoot.ask("I have " + numberOfSiblings() + " sibling(s)... May I sit down?");
        } else if (q.contains("many")) {
            q = Greenfoot.ask("There are " + numStudents + " students in the class... May I sit down?");
        } else {
          q = Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
        
         if (q.equalsIgnoreCase("yes")) {
            Greenfoot.delay(10);
            sitDown();
        } else {
            answerQuestion(); // recursion if answer is no
        }
        
    }
    
    /**
     * Prints the first and last name to the console
     */
    public void getName() {
        System.out.println("My name is " + firstName + " " + lastName + ".");
    }
    
    /**
     * Prints the passed string to the console
     * @param s Text to print to the console
     */
    public void myHobby(String s) {
        System.out.println(s);
    }
    
    /**
     * Returns the number of siblings
     * @return number of siblings as an integer
     */
    public int numberOfSiblings() {
        return numBrothers + numSisters;
    }
    
     /**
     * Returns the number of brothers
     * @return number of brothers as an integer
     */
    public int numberOfBrothers() {
        return numBrothers;
    }
    
     /**
     * Returns the number of sisters
     * @return number of sisters as an integer
     */
    public int numberOfSisters() {
        return numSisters;
    }
    
    /**
     * Special method
     * Teleport around the classroom and rotate
     * 
     * Populates a 3x125 2D array with a random x coordinate, random y coordinate, and random angle in degrees
     * Plays the name sound file
     * Loops through the 2D array and transforms the image and plays a windows error sound every 10ms
     */
    private void special() {
        int maxCentiseconds = 125;
        
        int[][] locrot = new int[maxCentiseconds][3];
        for (int i = 0; i < maxCentiseconds; i++) {
            locrot[i][0] = (int) (Math.random() * 11.0);
            locrot[i][1] = (int) (Math.random() * 5.0);
            locrot[i][2] = (int) (Math.random() * 360.0);
        }
        
        sayName(soundFile);
        Greenfoot.delay(100);
        
        for (int i = 0; i < maxCentiseconds; i++) {
            Greenfoot.delay(1);
            setLocation(locrot[i][0], locrot[i][1]);
            GreenfootImage img = new GreenfootImage(standingFile);
            img.rotate(locrot[i][2]);
            setImage(img);
            Greenfoot.playSound("windowserror.wav");
        }
        
        returnToSeat();
    }
}

 

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The RishikaThorat class can be used as a model for your own class that represents you and your seating location in AP CSA
 * 
 * @author Mr. Kaehms
 * @version 2.0 Aug 13, 2019
 */
public class RishikaThorat extends Student implements SpecialInterestOrHobby
{

    /**
     * Constructor for the RishikaThorat class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public RishikaThorat(String f, String l, int r, int s) { //Class that creates my avatar
        firstName=f; //Sets my firstname as the variable 'f'
        lastName=l; //Sets my last name as the variable 'l'
        myRow=r; //Sets the row I am in as the variable 'r'
        mySeat=s; //Sets my seat as the variable 's'
        setLocation(mySeat, myRow); //Sets my location as a coordinate of my seat and the row I am in. 
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg.jpeg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg.jpeg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     */
    public RishikaThorat() {
        firstName="Rishika";
        lastName="Thorat";
        myRow=4;
        mySeat=3;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg.jpeg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg.jpeg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    
     /**
     * In this method, it shows what will happen when my avatar is clicked on. If I am sitting down,
     * it will set my 'sitting' to false, which changes my image. Then, my sound file is played. If I am not
     * sitting down and am clicked on, my avatar will answer the question(s) and sit down if told to do so. 
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I like to dance and sing!");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                circleClass();  // Kilgore Trount's special method... Please write one of your own. You can use this, but please modify it and be creative.
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method allows the user to interact with my avatar through a question and answer interface, and provides
     * a question which allows the user to make the avatar sit down or answer more questions. 
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know?");
        boolean flag = true;
        
        while (flag) {
            
            if (q.contains("summer homework") && (q.contains("hard"))){
            q=Greenfoot.ask("2D arrays, scope and recursion! May I sit down?");
                if(q.contains("yes")) {
                    flag=false;
                }
                else {
                    q=Greenfoot.ask("Okay, what else would you like to know?");
                    continue;
                }
            }
            
            if (q.contains("2D arrays") && (q.contains("tell me more"))){
            q=Greenfoot.ask("2D Arrays are essentially arrays of arrays. For this project, I used a 2D array for my project! May I sit down?");
                if(q.contains("yes")) {
                    flag=false;
                }
                else {
                    q=Greenfoot.ask("Okay, what else would you like to know?");
                    continue;
                }
            }
            
            if (q.contains("scope") && (q.contains("tell me more"))){
            q=Greenfoot.ask("The scope defines the area or block of code in which a variable is accessible. May I sit down?");
                if(q.contains("yes")) {
                    flag=false;
                }
                else {
                    q=Greenfoot.ask("Okay, what else would you like to know?");
                    continue;
                }
            }
            
            if (q.contains("recursion") && (q.contains("tell me more"))){
            q=Greenfoot.ask("Recursion is a process in which a method calls on itself repeatedly. May I sit down?");
                if(q.contains("yes")) {
                    flag=false;
                }
                else {
                    q=Greenfoot.ask("Okay, what else would you like to know?");
                    continue;
                }
            }
            
            if (q.contains("how many") && (q.contains("students"))){
            q=Greenfoot.ask("There are: "+numStudents+" students in my CSA class! May I sit down?");
                if(q.contains("yes")) {
                    flag=false;
                }
                else {
                    q=Greenfoot.ask("Okay, what else would you like to know?");
                    continue;
                }
            }
            
            if (q.contains("summer") && (q.contains("vacation"))){
            q=Greenfoot.ask("I went to New York and D.C! May I sit down?");
                if(q.contains("yes")) {
                    flag=false;
                }
                else {
                    q=Greenfoot.ask("Okay, what else would you like to know?");
                    continue;
                }
            }
            
            if (q.contains("favorite") && (q.contains("subjects"))){
            q=Greenfoot.ask("CSA, AP Environmental Science and Economics of Business Ownership! May I sit down?");
                if(q.contains("yes")) {
                    flag=false;
                }
                else {
                    q=Greenfoot.ask("Okay, what else would you like to know?");
                    continue;
                }
            }
           else {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
          if (q.contains("yes")){
              flag=false;
            }
          if (q.contains("no")){
              q=Greenfoot.ask("Okay, what else would you like to know?");
              continue;
            }
        }
    }
}

     /**
     * This is a local method specific to the RishikaThorat class used to animate my avatar and randomize where it moves once clicked on.
     */
    public void circleClass(){
        setLocation(0,0);
         Greenfoot.delay(10);
        // move right
        int animation[][] = new int [6][2];
       
        for (int i=0; i<animation.length; i++) {
            int locationX = (int) (Math.random() * 10 + 8);
            int locationY = (int) (Math.random() * 2 + 4);
            animation[i][0] = locationX;
            animation[i][1] = locationY;
        }
        for (int i=0; i<animation.length; i++) {
            setLocation(animation[i][0], animation[i][1]);
        }
           Greenfoot.delay(20);
           returnToSeat();
    }
     public void myHobby(String s) {
         System.out.println(s);
}

}

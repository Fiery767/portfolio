import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.lang.Math;

/**
 * The JasleenKaur class defines Jasleen Kaur and sets the state of 
 * 
 * @author Jasleen Kaur
 * @version 1.0 Aug 26, 2019
 */
public class JasleenKaur extends Student implements SpecialInterestOrHobby
{
    //VARIABLES//
    private int dropSpeed = 1;
    
    /**
     * Constructor for the JasleenKaur class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public JasleenKaur(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  
        setImage(portraitFile);
        sitting=true; //not moving
        numStudents++;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     */
    private JasleenKaur() {
       firstName="Jasleen";
       lastName="Kaur";
       myRow=1;
       mySeat=7;
       
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
       soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
       setImage(portraitFile);
       sitting=true;
        numStudents++;
    }
    
     /**
     * Act - do whatever the JasleenKaur actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */   
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I like space!");
                
                circleClass(); //preform animation 
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     */
    public void answerQuestion()
    {
        String q=Greenfoot.ask("What would you like to know");
        if (q.contains("what did you find hard or challenging about the summer homework")){
            q=Greenfoot.ask("2D arrays, while loops, and recursion were hard for me because I couldn't understand how to properly impliment them... May I sit down?");
          }
        else if(q.contains("can you tell me  more about 2D arrays")){
             q=Greenfoot.ask("Yes. 2D arrays are arrays within arrays. This is done by creating a for loop within a for loop and these arrays hold the reference data to the actual value unlike array lists... May I sit down?");
        }
        else if(q.contains("summer")){
            q=Greenfoot.ask("It was good. I went on a tour of the SF bay and saw Alcatraz and I volunteered a lot!... May I sit down?");
        } 
        else if(q.contains("number")){
        int[][] arr = { { 1, 2 }, { 3, 4 } }; 
         for (int i = 0; i < 2; i++) { 
             for (int j = 0; j < 2; j++) {
                 System.out.print(arr[i][j] + " "); 
            }
        }
        System.out.println();
        System.out.println(q=Greenfoot.ask("What's your favorite number?"));
        if (q.contains("1")){
            q=Greenfoot.ask("First is the worst... May I sit down?");
        }
        else if (q.contains("2")){
            q=Greenfoot.ask("Second isn't always best... May I sit down?");
        } 
        else if(q.contains("3")){
            q=Greenfoot.ask("I bet you have a treasure chest... May I sit down?");
        }
        else if (q.contains("4")){
            q=Greenfoot.ask("I like the number 4 too... May I sit down?");
        }
        else{
            q=Greenfoot.ask("That's not a listed number... May I sit down?");
        }
       }
        else if (q.equals("yes")){
            Greenfoot.delay(10);
            sitDown();
            returnToSeat();
        }
        else {
            q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
        
    }
    
    /**
     * This is a local method specific to the JasleenKaur class used to animate the character once the image is clicked on.
     * Will spin the character in a circle.
     */
    public void circleClass()
    {

        for (int i=1;i<=19;i++){
            move(Greenfoot.getRandomNumber(360)); //spins in a circle
            //double speed = 10.0+Math.random()*5.0; -> code won't work
            //move(speed); -> not compadible error message
            Greenfoot.delay(10);
            setRotation(0); //unrotates character
            
        }
    }
    
    /**
     * 
     * This meathod that states the hobby of the student. The output wil be a string.
     */
     public void myHobby(String s) {
         
         System.out.println(s);
    }

}
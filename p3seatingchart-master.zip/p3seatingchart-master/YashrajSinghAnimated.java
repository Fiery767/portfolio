import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class YashrajSinghAnimated here.
 * 
 * @author Yash Raj Singh, CSA Per. 3
 * @version 1.0 August 10, 2019
 */
public class YashrajSinghAnimated extends Actor
{
    
   public String firstName;
   public String lastName;
   public int myRow;         // rows start in the front of class (1), and end in the back of class
   public int mySeat;        // seats are left to right, 1-8
   public boolean isActive;  // can you think of an algorithm that would allow you to use this
                             // variable to use keyboard entry for all the instance of a student
                             // that we will create?
                         
   public boolean sitting;   // Is the student sitting or standing (default sitting)                         
   
   public String imgFile; 
   public String soundFile; //      firstName.toLowerCase()+lastName.toLowerCase()+".ext"; (.wav or .jpg)
   Classroom clas = (Classroom) getWorld();
   private boolean played = false;
   private double timer = System.currentTimeMillis(); // Timer used to count to removing the instances of the obj
   private double timer2 = System.currentTimeMillis();
   
    /**
     * Act - do whatever the YashrajSinghAnimated wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act() 
    {
        if (System.currentTimeMillis() - timer >= 7000) {
                timer = 0;
                getWorld().removeObject(this); // Remove this object after 7 seconds
        }
        animation(); // Call the rotating animation every frame
        
    }    
    
    /**
     * This animation gets called every frame. 
     * Rotates the object by 50 degrees after a delay of 1.5 seconds has been met. 
     */
    private void animation() {
        if (played == false && System.currentTimeMillis() - timer2 >= 1500) {
           Greenfoot.playSound("YashrajSingh.wav");
           played = true;
        } // Second timer waits for the first invocation of my name to completely finish
        Greenfoot.delay(1);
        turn(50); // Turn 50 degrees every frame
    }
    
    /**
     * Constructor for the YashrajSinghAnimated class.
     * Used in YashrajSingh class to instantiate rotating copies of the same image.
     */
    public YashrajSinghAnimated() {
        firstName="Yash Raj";
        lastName="Singh";
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
        imgFile= "yashrajsingh-standing.jpeg";
        soundFile= "YashrajSingh.wav";
        setImage(imgFile);
    }
}

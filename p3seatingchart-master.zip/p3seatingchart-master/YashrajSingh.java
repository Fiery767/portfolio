import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

/**
 * 
 * @author Yash Raj Singh, CSA Per. 3
 * @version 1.0 August 10, 2019
 */
public class YashrajSingh extends Student implements SpecialInterestOrHobby
{

    /**
     * Constructor for the YashrajSingh class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public YashrajSingh(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile= "yashrajsingh.jpg";
        standingFile= "yashrajsingh-standing.jpeg";
        soundFile= "YashrajSingh.wav";
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     */
    public YashrajSingh() {
        firstName="Yash Raj";
        lastName="Singh";
        myRow=3;
        mySeat=7;
        portraitFile= "yashrajsingh.jpg";
        standingFile= "yashrajsingh-standing.jpeg";
        soundFile= "yashrajsingh.wav";
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    
     /**
     * Act - do whatever the YashrajSingh actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I love to program!");
            
                animation();  // YashrajSingh's special method
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     * 
     * This method expects multiple questions from the user, and attempts to answer them. 
     */
    public void answerQuestion() {
        boolean sit = false;
        
        while (sit == false) {
            
            String q = Greenfoot.ask("What would you like to know?");
            
            if (q.contains("hard")){
                q = Greenfoot.ask("2D arrays, recursion, and merge sort... May I sit down?");
            } else if (q.contains("siblings")) {
                q = Greenfoot.ask("I have one sister... May I sit down?");
            } else if (q.contains("sort")) {
                q = Greenfoot.ask("The different types of sorts are the most interesting to me... May I sit down?");
            } else if (q.contains("algorithms")) {
                q = Greenfoot.ask("Because there are so many different ways to do algorithms, it is the most complex topic I've learnt so far... May I sit down?");
            } else {
              q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            }
            
            if (q.equals("yes")) {
                sit = true;
            }
        }
        
        Greenfoot.delay(10);
        sitDown();
        
    }
    /**
     * The animation method creates a new instance of the YashrajSinghAnimated Class on every position on the seating chart.
     * The YashrajSinghAnimated class handles the animation after instantiation.
     * Uses a 2D array to loop through all the positions and instantiate my copy at each position.
     */
    public void animation(){
        
        Greenfoot.delay(10);
       
        // Positions of all the seats in the class. 
        int[][] positions = {
          {1, 1},  {1, 2}, {1, 3}, {1, 4}, {1, 5}, {1, 6}, {1, 7},
          {2, 1},  {2, 2}, {2, 3}, {2, 4}, {2, 5}, {2, 6}, {2, 7},
          {3, 1},  {3, 2}, {3, 3}, {3, 4}, {3, 5}, {3, 6}, {3, 7},
          {4, 1},  {4, 2}, {4, 3}, {4, 4}, {4, 5}, {4, 6}, {4, 7}
          
        };
        
        ArrayList<YashrajSinghAnimated> pics = new ArrayList<YashrajSinghAnimated>();
        
        for (int i = 0; i < positions.length; i++) {
            YashrajSinghAnimated pic = new YashrajSinghAnimated();
            getWorld().addObject(pic, positions[i][1], positions[i][0]);
        }
           Greenfoot.delay(20);
           returnToSeat();
   
    }
    
    /**
     * @param string; A type of hobby or pastime. 
     */
    public void myHobby(String s) {
         System.out.println(s);
}

}

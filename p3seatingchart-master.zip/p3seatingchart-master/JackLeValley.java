
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.lang.Math;
/**
 * Jack LeValley
 * 
 * @author Jack LeValley
 * @version 1.0 Sept, 11, 2019
 */
public class JackLeValley extends Student implements SpecialInterestOrHobby, NumberOfSiblings
{
    int Brothers = 1;
    int Sisters = 0;
    /**
     * This is the constructor if you do pass in a name and seating location.
     * Sets my first and last name, my location to be set, my images, my soundfile, whether im sitting or not, and counts me as a student.
     */
    public JackLeValley(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".JPG";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     * 
     * Sets my first and last name, my location to be set, my images, my soundfile, whether im sitting or not, and counts me as a student.
     */
    public JackLeValley() {
        firstName="Jack";
        lastName="LeValley";
        myRow=3;
        mySeat=5;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    
     /**
     * Act - do whatever the JackLeValley actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     * Plays when the actor is clicked on, it stands me up, says my name, my hobby, and plays my animation. If I am not sitting, then when clicked it asks me a question.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I like soccer and playing videogames!");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                destroyUniverse();  // Kilgore Trount's special method... Please write one of your own. You can use this, but please modify it and be creative.
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints my first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     * 
     * One may use the keywords, "brother", "sister", "sibling", but if you say "hard", then "array", "recursion", "wrapper", "value", "foreach", can be used after. There are five choices
     * after one asks what was hard. If I do not get a yes reply after asking if I can sit down, then I will ask what would you like to know again
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know");
        if (q.contains("hard")){
            q=Greenfoot.ask("2D arrays, recursion, wrapper classes, pass by value, foreach loops");
            if (q.contains("array")){
                q=Greenfoot.ask("Having to iterate through the arrays and set them up can be sometimes confusing and take quite a bit of time. May I sit down?.");
            }
            else if (q.contains("recursion")){
                q=Greenfoot.ask("Getting the correct syntax right and creating the correct base case for your project can be difficult to remember without a compiler. May I sit down?");
            }
            else if (q.contains("wrapper")){
                q=Greenfoot.ask("Remembering all the wrapper classes' names and when to use them can be quite a bit confusing. May I sit down?");
            }
            else if (q.contains("value")){
                q=Greenfoot.ask("Remembering that primitive data types can't go through the class is difficult to remember when you can't compile it on a test or quiz. May I sit down?");
            }
            else if (q.contains("foreach")){
                q=Greenfoot.ask("The syntax is easy to mess up and one needs to know what they are iterating through very well for it to work on it's first try. May I sit down?");
            }
        } else if (q.contains("brother")) {
            q = Greenfoot.ask("I have " + numberOfBrothers() + " brother(s)... May I sit down?");
        } else if (q.contains("sister")) {
            q = Greenfoot.ask("I have " + numberOfSisters() + " sister(s)... May I sit down?");
        } else if (q.contains("sibling")) {
            q = Greenfoot.ask("I have " + numberOfSiblings() + " sibling(s)... May I sit down?");
        } else if (q.contains("many")) {
            q = Greenfoot.ask("There are " + numStudents + " students in the class... May I sit down?");
        }
        else {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
         if (q.equals("yes")){
            Greenfoot.delay(10);
            sitDown();
        }
        else{
            answerQuestion();
        }
        
    }
    /**
     * This is my local method specific to the JackLeValley class used to animate my character once the image is clicked on.
     * It sets my location to a different place, plays the sound, plays through the animation using multiple frames, uses 2d array to randomize the time in between everyone dying, uses an
     * array list to shuffle everyone and eliminate half of the classroom, then sits me back down again.
     * 
     * The 2d array assigns random values to each spot using math.random for a value between 0 and 1 and using a multiplier on it, but setting it as an integer for future use.
     * After that, the delay is decided by picking a random slot in the greenfoot array that was assigned earlier. 
     */
    public void destroyUniverse(){
         setLocation(5,4);
         Greenfoot.delay(80);
         Greenfoot.playSound("gauntletsound.wav");
         Greenfoot.delay(160);
         setImage("thanosenter6.jpg");
         Greenfoot.delay(10);
         setImage("thanosenter5.jpg");
         Greenfoot.delay(10);
         setImage("thanosenter4.jpg");
         Greenfoot.delay(10);
         setImage("thanosenter3.jpg");
         Greenfoot.delay(10);
         setImage("thanosenter2.jpg");
         Greenfoot.delay(10);
         setImage("thanosenter1.jpg");
         Greenfoot.delay(10);
         getImage().setTransparency(0);
         int[][] array = new int[10][6];
         double multiplier = 20;
         for (int row = 0; row < array.length; row++) {
            for (int col = 0; col < array[row].length; col++) {
                 array[row][col] = (int)(Math.random() * multiplier);
            }
         }
         ArrayList<Student> images = new ArrayList<>();
         images.addAll(getWorld().getObjects(Student.class));
         Collections.shuffle(images);
         for (int i = 0; i < images.size()/2; i++){
            Greenfoot.delay(array[Greenfoot.getRandomNumber(10)][Greenfoot.getRandomNumber(6)]);
            images.get(i).setImage("ash.jpg");
         }
         Greenfoot.delay(10);
         setImage(standingFile);
         GreenfootImage image = getImage();
         image.scale(image.getWidth() - 200, image.getHeight() - 250);
         setImage(image);
         returnToSeat();
    }
      /**
     * Returns what my hobby is
     * Returns what my hobby is as a string
     */
    public void myHobby(String s) {
         System.out.println(s);
    }
    /**
     * Returns the number of siblings
     * Returns number of siblings as an integer
     */
    public int numberOfSiblings() {
        return Brothers + Sisters;
    }
    
     /**
     * Returns the number of brothers
     * Returns number of brothers as an integer
     */
    public int numberOfBrothers() {
        return Brothers;
    }
    
     /**
     * Returns the number of sisters
     * Returns number of sisters as an integer
     */
    public int numberOfSisters() {
        return Sisters;
    }
}
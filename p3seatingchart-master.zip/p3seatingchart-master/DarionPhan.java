import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The KilgoreTrout class can be used as a model for your own class that represents you and your seating location in AP CSA
 * 
 * @author Mr. Kaehms
 * @version 2.0 Aug 13, 2019
 */
public class DarionPhan extends Student implements SpecialInterestOrHobby
{
    
    private GreenfootImage literally_me = new GreenfootImage ("literally_me.png");
    /**
     * Constructor for the DarionPhan class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (Darion)
     * @param String l (Phan)
     * @param int r (row of seating arrangement. My row is 3)
     * @param int s (seat number within row seating arrangement. My column is 4)
     * 
     */
    public DarionPhan(String f, String l, int r, int s) {
        numStudents++;
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".JPG";    // Make sure to name your image files firstlast.JPG, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.JPG";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        
        
        sitting=true;
    }


    /**
     * Default constructor
     * Creates an image of me that can be interacted with  
     * 3,4 is the is my seat in the classroom.
     */
    public DarionPhan() {
        firstName="Darion";
        lastName="Phan";
        myRow=3;
        mySeat=4;
        //imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".JPG";
        portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".JPG";
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.JPG";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * Act - do whatever the DarionPhan actor wants to do .This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment
     * .Creates the basketballhoop image whenever my face is clicked
     * 
     * .Defines a vaiable called myHobby
     * 
     * .It runs the method for movement called kobeClass and allows me to answer questions
     * 
     * .Then I return to my area once it finishes
     */   
    public void act() 
    {
        // Add your action code here.
        
        if(Greenfoot.mouseClicked(this)){
          
            
            if (sitting){

        
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
                
                
            
                myHobby("I like economics and #GoGaels");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                kobeClass();
                
                setImage("darionphan-standing.JPG");
                // Kilgore Trount's special method... Please write one of your own. You can use this, but please modify it and be creative.
            }
            else {
                setImage("darionphan-standing.JPG");
                setLocation(5,3);
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     * 
     * Answers the questions by looking for a combination of characters and outputing a response to it
     * 
     * Examples include sports, hobbies, and siblings 
     */
    public void answerQuestion(){
        setLocation(5,3);
        setImage("darionphan-standing.JPG");
        String q=Greenfoot.ask("What would you like to know");
        if (q.contains("number" )) {
            q= Greenfoot.ask("There are " +numStudents + " students in the classroom. May I sit down?");
        }
        
        if (q.contains("students")){
            q= Greenfoot.ask("There are " +numStudents + " students in the classroom. May I sit down?");
        }
        if (q.contains("hard")){
            q=Greenfoot.ask("2D arrays, recursion, and merge sort... May I sit down?"); 
            sitDown();

        }
        if (q.contains("2D arrays"))
            q =Greenfoot.ask("This is basically a for loop inside of a for loop. It allows a lot of data to be stored and categorized. May I sit down?");
       if (q.contains("concatenation"))
            q =Greenfoot.ask("This is basically adding two separate strings or data types into one string. An example of concatenation is (9 + 3 + \"equals 12\") May I sit down?");
            if (q.contains("recursion"))
            q =Greenfoot.ask("This is basically a for loop inside of a for loop inside of a for loop inside of a for loop.... I don't fully understand it, but I'm working on it. May I sit down?");
        if (q.contains("merg"))
            q =Greenfoot.ask("I know the differences between the loops, but not how to build them. May I sit down?");
       if (q.contains("Array lists"))
            q =Greenfoot.ask("This can hold non-Primitive variable types and doesn't have a fixed size. It is really good for making lists. May I sit down?");     
            if (q.contains("sibling")){
            q=Greenfoot.ask("I have " + 1 + " sibling. It is my sister, Tavien. She goes to UC Davis... May I sit down?");
            sitDown();
        }
        if (q.contains("hobb")){
            q=Greenfoot.ask("My hobbies include studying economics and watching YouTube videos... May I sit down?");
            sitDown();
        }
        if (q.contains("sport")){
            q=Greenfoot.ask("I play volleyball! ... May I sit down?");
            sitDown();
        }
        if (q.contains("ball")){
            q=Greenfoot.ask("I play volleyball! ... May I sit down?");
            sitDown();
        }
        if (q.contains("girlfriend")){
            q=Greenfoot.ask(":'( no, but I'm working on it. May I sit down?");
            sitDown();
        }
        if (q.equals("yes")){
            Greenfoot.delay(10);
            sitDown();
        }
       
        else {
            q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            answerQuestion();
        
        }
        
        
    }
    /**
     * This is a local method specific to the DarionPhan class used to animate the character once the image is clicked on.
     * You can write your own methods to perform your own animation for your character/avatar.
     * 
     * Waits for 10 seconds and uses a 2D array
     */
    public void kobeClass(){
      //  setLocation(0,0);
         Greenfoot.delay(10);
       
        basketballhoop basketballhoop = new basketballhoop();
        getWorld().addObject(basketballhoop, 6, 2);
        int [][] moveDarion = new int [6][2];
       
        for (int p = 0; p <moveDarion.length; p++) {
            int randomMovement = (int)(Math.random() * 4);
            for (int q = 0; q <= moveDarion[p].length; q++)
            {
                 
               setLocation (p +  2*randomMovement ,q + randomMovement );
               Greenfoot.delay(10);
            }
           }
        setImage(literally_me);
        
        for (int i = 0; i < 10; i++) {
            setLocation (i, i^2 +4 );
            Greenfoot.delay(7);
            setRotation(i * 18);
        }
        setLocation(5, 3);
        setRotation(0);
        setImage("darionphan-standing.JPG");
        getWorld().removeObject(basketballhoop);
        setLocation(5,3);
        
    
    }
    /**
     * prints the string "myHobby" to the place where text can be seen
     */
     public void myHobby(String s) {
         System.out.println(s);
}
}

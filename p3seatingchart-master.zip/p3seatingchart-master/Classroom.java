import java.util.*;
import greenfoot.*;
import java.util.ArrayList;
 // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
 
/**
 * Write a description of class Classroom here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Classroom extends World
{
    private ArrayList<Object> listo = new ArrayList<Object>();
    /**
     * Constructor for objects of class Classroom.
     * 
     */
    public Classroom()
    {    
        // Create a new world with 10x6 cells with a cell size of 130x130 pixels.
        super(10, 6, 130); 

        prepare();
    }
    
    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
   
     private void prepare()
    {
        // Adds three lines to this doc with your class constructor and your row and seat number
        // Make sure to match your first and last name to the class file you created.

        Student.resetNumStudents();
        
        /* Example */
        
        MelodyWang melodywang = new MelodyWang("Melody", "Wang", 4, 4);
        addObject(melodywang, 4, 4);
        melodywang.sitDown();
        
        DarrenChui darrenchui = new DarrenChui("Darren", "Chui", 1, 4);
        addObject(darrenchui, 4, 1);
        darrenchui.sitDown();
		
        ZuhairJafri zuhairjafri = new ZuhairJafri("Zuhair", "Jafri", 1, 5);
        addObject(zuhairjafri, 5, 1);
        zuhairjafri.sitDown();
        
        FranciscoChiocconi franciscochiocconi = new FranciscoChiocconi("Francisco", "Chiocconi", 1, 3);
        addObject(franciscochiocconi, 1, 1);
        franciscochiocconi.sitDown();
		
        SubashShibu subashshibu = new SubashShibu("Subash", "Shibu", 3, 6);// sets the parameters for my function
        addObject(subashshibu, 1, 1);
        subashshibu.sitDown();

        KevinLiu kevinliu = new KevinLiu("Kevin", "Liu", 2, 7);
        addObject(kevinliu, 1, 1);
        kevinliu.sitDown();
        
        JeffCheema kilgoretrout = new JeffCheema("Jeff", "Cheema", 1, 2);
        addObject(kilgoretrout, 2, 1);
        kilgoretrout.sitDown();

        YuvrajKhullar yuvrajkhullar = new YuvrajKhullar("Yuvraj", "Khullar", 2, 1);
        addObject(yuvrajkhullar, 2, 1);
        yuvrajkhullar.sitDown();
        
        WangMingye myw = new WangMingye("Mingye", "Wang", 4, 5);
        addObject(myw, 5, 4);
        
        AarushAitha aarushaitha = new AarushAitha("Aarush", "Aitha", 1, 1);
        addObject(aarushaitha, 1, 1);
        aarushaitha.sitDown();
        
        JacobSommer jacobsommer = new JacobSommer();
        addObject(jacobsommer, 4, 1);
        jacobsommer.sitDown();
        
        RishikaThorat rishikathorat = new RishikaThorat();
        addObject(rishikathorat, 4, 3);
        rishikathorat.sitDown();
        
        AkamaiWong akamaiwong = new AkamaiWong();
        addObject (akamaiwong, 4, 7);
        akamaiwong.sitDown();
      
        MeganNgai meganngai = new MeganNgai("Megan", "Ngai", 3, 1);
        addObject(meganngai, 3, 1);
        meganngai.sitDown();
        
        RanjuKrishna ranjukrishna = new RanjuKrishna("Ranju", "Krishna", 2, 2);
        addObject(ranjukrishna, 2, 2);
        ranjukrishna.sitDown();
         
        BrandonLau brandonlau = new BrandonLau("Brandon", "Lau", 2, 3);
        addObject(brandonlau, 2, 3);
        brandonlau.sitDown();
        
        YogaKanneboina yogakanneboina = new YogaKanneboina();
        addObject(yogakanneboina, 1, 6);
        yogakanneboina.sitDown();
		
        YashrajSingh yashsingh = new YashrajSingh("Yash Raj", "Singh", 3, 7);
        addObject(yashsingh, 3, 7);
        yashsingh.sitDown();
		
        AlanLiang alanliang = new AlanLiang("Alan", "Liang", 2, 6);
        addObject(alanliang, 2, 6);
        alanliang.sitDown();
        
        DonnaPrince donnaprince = new DonnaPrince("Donna","Prince", 3, 5);
        addObject(donnaprince, 3, 5);
        donnaprince.sitDown();
        
        JasleenKaur jasleenkaur = new JasleenKaur("Jasleen", "Kaur", 1, 7);
        addObject(jasleenkaur, 1, 7);
        jasleenkaur.sitDown();
        
        KeaganWilson keaganwilson = new KeaganWilson("Keagan", "Wilson", 4, 6);
        addObject(keaganwilson, 4, 6);
        keaganwilson.sitDown();
        
        DarionPhan darionphan = new DarionPhan("Darion", "Phan", 3, 4);
        addObject(darionphan, 3, 4);
        darionphan.sitDown();
        
        KevinPark kevinpark = new KevinPark("Kevin", "Park", 3, 3);
        addObject(kevinpark, 3, 3);
        kevinpark.sitDown();
        
        JackLeValley jackl = new JackLeValley("Jack", "LeValley", 2, 5);
        addObject(jackl, 5, 2);
        jackl.sitDown();
        
    }  
}

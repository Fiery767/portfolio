import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This class creates the YogaKanneboina object and has the methods for its animations and questions. 
 * 
 * @author Yoga Kanneboina 
 * @version 1
 */
public class YogaKanneboina extends Student implements SpecialInterestOrHobby
{
    
         /**
     * Constructor for the KilgoreTrout class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public YogaKanneboina(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     * 
     * The constructor has the class name, which is YogaKanneboina. The coordinate is set to (1,6). 
     * This gets the sitting, standing, and name files. It also sets the variable sitting to true
     * to indicate that the object is sitting. 
     */
    public YogaKanneboina() {
        firstName="Yoga";
        lastName="Kanneboina";
        myRow=1;
        mySeat=6;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       numStudents++; 
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setLocation(1,6);
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * Act 
     * This method is called when the run button is pressed. If the picture is currently sitting and the user 
     * presses on it, the standing image will be displayed and the animation method circle() will be called. 
     * If the image is already standing, the answerQuestion() method will be called and the picture will sit down. 
     */   
    public void act() 
    {
        // Add your action code here.
        //sitDown();
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                getName();
                myHobby("I like to dance!");
                sitting=false; 
                sayName(soundFile);
                setImage(standingFile);
                circle();
                setImage(standingFile);
                
            }
            else {
                answerQuestion();
                sitDown();
                
            }
                    
        }
    } 
    
    
    /**
     * This method is for the animation. It picks a random number from 0 to 8 for the x coordinate and it 
     * picks a random number from 0 to 4 for the y coordinate of the picture. Then, a 2D array is made 
     * with 9 rows and 7 colmns. The for loops iterate through the arrays assign a random number from 0 
     * to 360 to each spot. Then, the image will rotate a certain degree based on the random number assigned to each cell. 
     * Once this is over, the image's rotation is set to 0 degrees and it returns to its seat by calling the 
     * returnToSeat() method. 
     */
    public void circle()
    {
        
       setLocation((Greenfoot.getRandomNumber(8)), Greenfoot.getRandomNumber(4));
        int[][] list = new int[8][6];
        for (int k = 0; k < 8; k++)
        {
            for (int i = 0; i < 6; i++)
            {
                list[k][i] = Greenfoot.getRandomNumber(360);
                setRotation(list[k][i]);
                Greenfoot.delay(5);
            }
        }
        setRotation(0);
        returnToSeat();
    }
    
    
    /**
     * Prints the first and last name to the console. 
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. If you provide extra
     * classes, make sure to fully document so other students can use the same interface.
     * 
     * This method accepts questions and uses the contains() method to find key words and infer the question that is being asked. 
     * In each if statement, the program will answer with an answer to the questions. If there are no if statements that fit the 
     * question, the program asks the user if the object can sit down and based on the answer, the object will either sit down 
     * or repeat the animation by calling circle() method. 
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know");
        if (q.contains("enjoy")){
            q=Greenfoot.ask("Something I enjoyed learning about in Java was 2D arrays. May I sit down?");
        
        }
        else if (q.contains("hard")){
            q = Greenfoot.ask("Learning about constructors and instance variables was hard. May I sit down?");
        }
        else if(q.contains("constructor"))
        {
            q = Greenfoot.ask("Constructors must have the same name as the class and it initialises an object. May I sit down?");
        }
        else if(q.contains("students")){
            q = Greenfoot.ask("There are " + numStudents + " in this class. May I sit down?");
        }
        else if(q.contains("CSA")){
            q = Greenfoot.ask("I took CSA because I love coding and being able to create my own programs. May I sit down?");
        }
        
        else if(q.contains("subjects")){
            q = Greenfoot.ask("My favorite subjects are engineering and biology. May I sit down?");
        }
        
        else {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
        
         if (q.equals("yes")){
            Greenfoot.delay(10);
            sitDown();
        }
        
        else {
            Greenfoot.delay(10);
            circle();
            answerQuestion();
        }
        
    }
    
     /**
      * This method takes in a string argument and prints it out. 
      */
     public void myHobby(String s) {
         System.out.println(s);
    }

    }    


import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BrandonLau here.
 * 
 * @author Brandon Lau
 * @version (a version number or a date)
 */
public class BrandonLau extends Student
{
    /**
     * Constructor for the BrandonLau class.
     * 
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public BrandonLau(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        numStudents++;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.png";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
    }
    /**
     * Default constructor for the BrandonLau class
     */
    public BrandonLau() {
        firstName="Brandon";
        lastName="Lau";
        myRow=2;
        mySeat=3;
        numStudents++;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * This method is called whenever the 'Act' or 'Run' button gets pressed 
     * in the environment. After the student image is clicked, it prints out
     * the name of the student and prints out its hobby. It then runs a unique
     * animation. After it is clicked again, it allows for questions to be asked.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I like to read books and play video games.");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                circleClass();  // special method
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * The user is prompted to ask a question. If the question contains 'hard'
     * then what the student finds hard is printed. If the question contains
     * 'hobbies', the student's hobbies are printed. The user is then prompted 
     * if they want to know more or if the student can just sit down.
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know?");
        int knowMore = 0;
        if (q.contains("hard")){
            q=Greenfoot.ask("I find recursions, and merge sort difficult... Would you like to know more or May I sit down?");
            knowMore = 1;
        }
        else if (q.contains("hobbies") || q.contains("interesting")) {
            q = Greenfoot.ask("I like to play video games and read books... Would you like to know more or May I sit down?");
            knowMore = 2;
        }
        else if (q.contains("students")) {
            q = Greenfoot.ask("There are " + numStudents + " students in the class. May I sit down?");
        }
        else {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
        if (q.contains("sit") || q.contains("yes")){
            Greenfoot.delay(10);
            sitDown();
        }
        else if (q.contains("more")){
            if (knowMore == 1){
                q = Greenfoot.ask("Recursions are very confusing as you have to keep track of the variable everytime it goes through. I understand the concept of merge sort, but I think it might be confusing to code. May I sit down?");
                if (q.contains("sit") || q.contains("yes")){
                    Greenfoot.delay(10);
                    sitDown();
                }
            }
            else if (knowMore == 2) {
                q = Greenfoot.ask("I enjoy reading books of all genres and playing strategy games. May I sit down?");
                if (q.contains("sit") || q.contains("yes")){
                    Greenfoot.delay(10);
                    sitDown();
                }
            }
        }
        
    }
    /**
     * This is a local method of the BrandonLau class. It is used to make the
     * character teleport to random coordinates 7 times and then walks around 
     * the class column by column while spinning after the user clicks on 
     * the image.
     */
    public void circleClass(){
        setLocation(0,0);
         Greenfoot.delay(10);
         int randomCoordinates[][]= new int[7][2];
         
         // generate random numbers and add to randomCoordinates
         for (int i=0;i<randomCoordinates.length; i++){
             int randomX = (int)(Math.random() * 9 + 1);
             int randomY = (int)(Math.random() * 5 + 1);
             randomCoordinates[i][0] = randomX;
             randomCoordinates[i][1] = randomY;
         }
           
        // teleport around randomly
        for (int i=0; i<randomCoordinates.length; i++) {
            setLocation(randomCoordinates[i][0], randomCoordinates[i][1]);
            Greenfoot.delay(3);
        }
         
        // move right while spinning
        for (int i=1;i<=9;i++){
            setLocation(i,0);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }
        // move back while spinning
        for (int i=1;i<=5;i++){
            setLocation(9,i);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
         // move left while spinning
        for (int i=9;i>=8;i--){
            setLocation(i,5);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
         // move Forward while spinning
        for (int i=5;i>=0;i--){
            setLocation(8,i);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }   
        // move left while spinning
        for (int i=8;i>=7;i--){
            setLocation(i,0);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
        // move back while spinning
        for (int i=1;i<=5;i++){
            setLocation(7,i);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
         // move left while spinning
        for (int i=7;i>=6;i--){
            setLocation(i,5);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
        // move Forward while spinning
        for (int i=5;i>=0;i--){
            setLocation(6,i);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }   
         // move left while spinning
        for (int i=6;i>=5;i--){
            setLocation(i,0);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
         // move back while spinning
        for (int i=1;i<=5;i++){
            setLocation(5,i);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
         // move left while spinning
        for (int i=5;i>=4;i--){
            setLocation(i,5);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
        // move Forward while spinning
        for (int i=5;i>=0;i--){
            setLocation(4,i);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }   
         // move left while spinning
        for (int i=4;i>=3;i--){
            setLocation(i,0);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
          // move back while spinning
        for (int i=1;i<=2;i++){
            setLocation(3,i);
            Greenfoot.delay(1);
            int turndeg = (int )(Math.random() * 360 + 1);
            turn(turndeg);
        }      
           Greenfoot.delay(20);
           setRotation(0);
           returnToSeat();
    }
    

     public void myHobby(String s) {
         System.out.println(s);
}
}

import java.util.ArrayList;
import java.util.Random;
import greenfoot.*;  

/**
 * @author Francisco Chiocconi
 * @version 1.0 Sep 10, 2019
 */
public class FranciscoChiocconi extends Student implements SpecialInterestOrHobby
{

    int row = 9;
    int col = 9;
    int [][] board = new int [row][col];

    /**
     *  Sets variable names to different Images to be used later in different methods     
    */
    public FranciscoChiocconi(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile="franciscochiocconi.jpg";    
        standingFile="franciscochiocconi.jpg";
        soundFile="franciscochiocconi.wav"; 
        setImage(portraitFile);
        sitting=true;
        numStudents++;

    }
    /**
     *  sets variable names for the files in order to use them later in other methods     
    */
    public FranciscoChiocconi() {//sets variable names for the files in order to use them later in other methods
        firstName="Francisco";
        lastName="Chiocconi";
        myRow=3;
        mySeat=1;
      
       portraitFile="franciscochiocconi.jpg";
       standingFile="franciscochiocconistanding.jpg";
        soundFile="franciscochiocconi.wav";
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    
    /**
     * acting class which works when the object is clicked and then uses the standing file as the picture, and then prints the hobby. After it runs the circle class which holds the animation using an array
     */
    
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println("");
                getName();
            
                myHobby("I like to play soccer!");
            
                circleClass();
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    
    /**
     *method in which gives user the ability to enter text, and depending on the answer, if it contains one of the phrases it will send a piece of dialogue back
      if the user says yes when he wants to sit down, the character will sit back down and end the conversation. When no is the answer the character continues standing
     */
    
    
    public void answerQuestion(){
        int sitdown = 1;
        if(sitdown==1)
        {
            String q=Greenfoot.ask("What would you like to know");
            
            if (q.contains("hard")){
                q=Greenfoot.ask("Overloaded Methods, Recursions, and 2d Arrays... May I sit down?");
            
            }
            if (q.contains("hobby")){
                q=Greenfoot.ask("I play soccer most days of the week and like to mess around on computers... May I sit down?");
            
            }
            if (q.contains("siblings")){
                q=Greenfoot.ask("I have a brother and a Sister... May I sit down?");
            
            }
            if (q.contains("leadership")){
                q=Greenfoot.ask("I was soccer captain for 2 years... May I sit down?");
                
            }
            if (q.contains("student")){
                q=Greenfoot.ask("I've been playing soccer since a little kid... May I sit down?");
            }
            if (q.contains("athlete")){
                q=Greenfoot.ask("I've been playing soccer since a little kid... May I sit down?");
            }
            if (q.contains("interest")){
                q=Greenfoot.ask("Things I found interseting were DeMorgan's Law, Oneway Flags, and Binary... May I sit down?");
            }
            if (q.contains("syntax")){
                q=Greenfoot.ask("Remembering the syntax for arrays will be hard but I will remember because the amount of brackets you put is what makes it a 1d, 2d, or 3d array... May I sit down?");
            }
            if (q.contains("java")){
                q=Greenfoot.ask("Remembering the syntax for arrays will be hard but I will remember because the amount of brackets you put is what makes it a 1d, 2d, or 3d array... May I sit down?");
            }
            if (q.contains("no")){
              String g=Greenfoot.ask("What Else would you like to know?");
            
            }
             if (q.equals("yes")){
                Greenfoot.delay(10);
                sitdown++;
                sitDown();
            }
             else {
              q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            }
           
        }
    }

    /**
     *The circle class contains the animation which starts by creating a random array by iterating through each row and column of an array and assigning it a random value
      in a set range. It then plays the sound, and iterates through the array and sets the location to the array. Alongside using math.random the image turns to a random degree.when the animation is 
      complete it then sets the location back to the assigned seat and sets the rotation to zero.
     */
    public void circleClass(){
         Greenfoot.delay(10);          
      
        for(int j =0; j<board.length; j++){
           int i = (int)(Math.random()*9 + 1);
           int n = (int)(Math.random()*5 + 1);
           
           board[j][0] = i;
           board[j][1] = n;
        }
        
        Greenfoot.playSound("franciscochiocconi.wav");

        for(int j =0; j<board.length; j++){
            setImage("franciscochiocconistanding.jpg");
            int degree = (int)(Math.random()*360 + 1);
            turn(degree);
            setLocation(board[j][0], board[j][1]);
            Greenfoot.delay(20);
        }
        Greenfoot.delay(20);
        setRotation(0);
        setImage("franciscochiocconi.jpg");
         returnToSeat();      
        }

        
      /**
     * Prints the preset hobby in the console
     */   
    public void myHobby(String s) {
             System.out.println(s);
       }
    
    }
   
   
 
    



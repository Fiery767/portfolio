import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class basketball here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class basketballhoop extends Actor
{
    /**
     * Act - do whatever the basketball wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private boolean canCatchGold(){

Actor gold = getOneObjectAtOffset(0, 0, DarionPhan.class);
if(gold != null) {
return true;
}
else {
return false;
}
}
private void CatchGold(){
Actor gold = getOneObjectAtOffset(100, 100, DarionPhan.class);
if(gold != null) {
getWorld().removeObject(gold);
    }

}
    public void act() 
    {
     
    }    
}


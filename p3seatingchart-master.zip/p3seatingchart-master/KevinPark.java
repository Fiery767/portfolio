import greenfoot.*; 

/**
 * The KevinPark class can be used as a model for your own class that represents you and your seating location in AP CSA
 * 
 * @author Kevin Park
 * @version 3.0 September 10, 2019
 */
public class KevinPark extends Student implements SpecialInterestOrHobby, NumberOfSiblings
{
    /**
     * number of brothers I have
     */
    private int numBrothers = 0;
    
    /**
     * This is the number of sisters I have
     */
    private int numSisters = 1;
    
    /**
     * Constructor for the KevinPark class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * numStudents adds students to the class number
     */

    public KevinPark(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile="kevinpark.wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    /**
     * Default constructor, if you don't pass in a name and seating location. 1,1 is the first cell in the upper left
     * of the classroom and so forth. Essentially builds my avatar for the classroom display.
     */
    public KevinPark() {
        firstName="Kevin";
        lastName="Park";
        myRow=1;
        mySeat=1;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile="kevinpark.wav";
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * Act - do whatever the KevinPark actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I like to play games!");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                circleClass();  // Kilgore Trount's special method... Please write one of your own. You can use this, but please modify it and be creative.
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends.  You can use this basic model, or come up
     * with some additional class and object that represents a blackboard, or a talking cartoon bubble etc. 
     * 
     * In this section, the player asks my avatar questions.
     * The questions are looped in a while loop that continuously runs the code unless the avatar is sit down which is seen through the 
     * seat variable.
     * The code utilizes 3 booleans in order to continuously loop through certain questions.
     * There are if statements that determine the possible answer choices for the asked questions.
     * Finally, there are for loops that loop through the talking animation.
     * The key words for the questions are: school, friends, favorite color, family, and students.
     * For family, I used the NumberOfSiblings class in the "other classes" category.
     */
    public void answerQuestion(){
        for (int i= 1; i<=4;i++){ //Plays mouth moving animation
           setImage("animate"+i+".jpg");
           Greenfoot.delay(5);
        }
        for (int i= 4; i>0;i--){ //Plays mouth moving animation
           setImage("animate"+i+".jpg");
           Greenfoot.delay(5);
        }
        boolean seat=true;
        boolean questions=true;
        boolean ask = false;
        String q=Greenfoot.ask("Hello, what would you like to know about me?"); //this is the first question asked to the user
        while (seat){
            while (questions){
                if(ask){

                   q=Greenfoot.ask("Ok then, what would you like to know?");
                }
                if (q.contains("school")){
                   for (int i= 1; i<=4;i++){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   for (int i= 4; i>0;i--){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   ask = false;
                   q=Greenfoot.ask("School is hard as I am taking a lot of hard classes. What else?");
                }
                else if (q.contains("favorite color")){
                   for (int i= 1; i<=4;i++){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   for (int i= 4; i>0;i--){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   ask = false;
                   q=Greenfoot.ask("My favorite color is red. Anything else?");
                }
                else if (q.contains("family")){
                   for (int i= 1; i<=4;i++){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   for (int i= 4; i>0;i--){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   ask = false;
                   q=Greenfoot.ask("I have "+numberOfSiblings()+" sibling. I have "+numberOfSisters()+" sister and "+ numberOfBrothers() + " brothers. Anything else?");
                }
                else if (q.contains("friends")){
                   for (int i= 1; i<=4;i++){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   for (int i= 4; i>0;i--){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   ask = false;
                   q=Greenfoot.ask("I have some friends. Anything else?");
                }            
                else if (q.contains("students")) {
                   for (int i= 1; i<=4;i++){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   for (int i= 4; i>0;i--){ //Plays mouth moving animation
                       setImage("animate"+i+".jpg");
                       Greenfoot.delay(5);
                   }
                   ask = false;
                    q = Greenfoot.ask("There are " + numStudents + " students in the class. Anything else?");
                }
                else{
                  questions = false;
                  ask = false;
                }
            }    
            for (int i= 1; i<=4;i++){ //Plays mouth moving animation
                setImage("animate"+i+".jpg");
                Greenfoot.delay(5);
            }
            for (int i= 4; i>0;i--){ //Plays mouth moving animation
                setImage("animate"+i+".jpg");
                Greenfoot.delay(5);
            }
            String n=Greenfoot.ask("I don't understand the question... May I sit down?"); 
            if (n.equals("yes")){
               sitDown();
               seat=false;
            }
            else{
               seat = true;
               ask=true;
               questions=true;
               for (int i= 1; i<=4;i++){ //Plays mouth moving animation
                  setImage("animate"+i+".jpg");
                  Greenfoot.delay(5);
               }
               for (int i= 4; i>0;i--){ //Plays mouth moving animation
                   setImage("animate"+i+".jpg");
                   Greenfoot.delay(5);
               }               
            }
    }
    }
    /**
     * This is a local method specific to the KevinPark class used to animate the character once the image is clicked on.
     * You can write your own methods to perform your own animation for your character/avatar. 
     * 
     * Here, the 2D array is located. It starts off empty.
     * The for loops following the creation of the 2D array develops x and y values for the list by using the Math.random function.
     * Then, there is a for loop that is used to iterate through all the generated points in order to make it seem as if my
     * character is teleporting.
     * After that, a mouth animation plays that uses a for loop to cycle through images to display the action of opening mouths.
     */
    public void circleClass(){
         Greenfoot.delay(10);
        int points[][] = new int[2][15]; //2d Array consisting of random points (none of them are in there right now)
        for(int i = 0; i  < points[1].length; i++) //creates points
        {
            points[1][i] =(int)(Math.random()*10); 
        }
        
        for(int x= 0; x<points[0].length; x++) //creates points
        {
            points[0][x]= (int)(Math.random()*6);
            
        }

        for(int t = 0; t < points[0].length; t++)
        {
            setLocation(points[0][t], points[1][t]);
            Greenfoot.delay(2);
           
        }
        setLocation(3,3);
        for (int i= 1; i<=4;i++){//Plays mouth moving animation
           setImage("animate"+i+".jpg");
           Greenfoot.delay(5);
        }
        for (int i= 4; i>0;i--){//Plays mouth moving animation
           setImage("animate"+i+".jpg");
           Greenfoot.delay(5);
        }
        for (int i= 1; i<=4;i++){//Plays mouth moving animation
           setImage("animate"+i+".jpg");
           Greenfoot.delay(5);
        }
        for (int i= 4; i>0;i--){//Plays mouth moving animation
           setImage("animate"+i+".jpg");
           Greenfoot.delay(5);
        }
        Greenfoot.delay(5);
        returnToSeat();
    }

    /**
    * This prints out the hobby of my avatar which is games in the console section.
    */
    
    public void myHobby(String s) {
         System.out.println(s);

       }
    /**
     * This just returns the number of siblings I have total
     */
    public int numberOfSiblings() {
        return numSisters + numBrothers;
    }
    
     /**
     * This just returns the number of brothers

     */
    public int numberOfBrothers() {
        return numBrothers;
    }
    
     /**
     * This returns number of sisters
     */
    public int numberOfSisters() {
        return numSisters;
    }
}

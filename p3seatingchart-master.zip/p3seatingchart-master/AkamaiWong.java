import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.lang.Math;

/**
 * The AkamaiWong class represents me and my seating location in AP CSA.
 * 
 * @author Akamai Wong
 * @version 1.0 Aug 27, 2019
 */
public class AkamaiWong extends Student implements SpecialInterestOrHobby
{

    /**
     * Constructor for the AkamaiWong class.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public AkamaiWong(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".png";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.png";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
    }
    /**
     * This constructor initializes the object AkamaiWong. It will provide the name, 
     * location (row&seat), image files, and sound file of the object. 
     */
    public AkamaiWong() {
        firstName="Akamai";
        lastName="Wong";
        myRow=4;
        mySeat=7;
       portraitFile="akamaiwong.png";
       standingFile="akamaiwong-standing.png";
        soundFile="akamaiwong.wav";
        numStudents++;
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * Act - do whatever the AkamaiWong actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment. In this case, it will do the following when the sitting 
     * image of the actor is clicked. It will change the picture to the standing picture, say the name of the actor 
     * (using the sound file), print the hobby text to the console, and call the action class, which is described later on. 
     * 
     * If the standing picture of the character is clicked, it will call the answer question method, described later on, and 
     * when this method is finished, it will call the sit down method to change the picture to the sitting one. 
     */   
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I love dogs, and often foster them from the local animal shelter!");
            
            
                actionClass();
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console.
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    
    
    /**
     * This method allows the user to interact with the student through a question and answer interface, and then
     * allow the student to sit down after the user indicates that the conversation has ended. 
     * 
     * The user can only answer one question that the user could ask: "What was hard about the summer homework?" in the first questioning stage. 
     * Any other question will not be valid. Once this original question has been asked, follow-up questions can be asked about this first question. 
     * These following questions will be accepted: 
     * "What was hard about 2-D arrays?"
     * "What was hard about recursion?"
     * "What was hard about loops?"
     * "What was hard about truth tables?"
     * After one question has been asked, others will not be accepted. Any further questioning will not be understood. 
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know?");
        while (q.equals("yes") == false || q.equals("no") == false) {  
        if (q.contains("hard")){
            q=Greenfoot.ask("On the summer homework, I thought that 2D arrays, recursion, for loops, while loops, and truth tables were difficult. May I sit down?");
            while (q.equals("yes") == false || q.equals("no") == false) {  
            if (q.contains("yes") == true) {
            Greenfoot.delay(10);
            sitDown();
            break;
            }
            if (q.contains("array") == true || q.contains("arrays") == true){
                q=Greenfoot.ask("Accessing a specific member in the 2D array was difficult. May I sit down now?");
            }
            if (q.contains("recursion") == true) {
                q=Greenfoot.ask("Finding how many times the recursion would occur was difficult. May I sit down now?");
            }
            if (q.contains("loop") == true || q.contains("loops") == true) {
                q=Greenfoot.ask("Knowing what the first character and last character the loop would print was difficult in both loops. May I sit down now?");
            }
            if (q.contains("truth") == true) {
                q=Greenfoot.ask("Finding the missing value in truth tables was difficult. May I sit down now?");
            }
            if (q.contains("no") == true) {
                q=Greenfoot.ask("Okay. May I sit down now?");
            }
            if (q.contains("yes") == true) {
                Greenfoot.delay(10);
                sitDown();
                break;
            }
            if (q.contains("yes") == false && q.contains("no")== false) {
                q=Greenfoot.ask("I don't understand the question. May I sit down now?");
            }
        }
        }
        if (q.contains("no") == true) {
            q=Greenfoot.ask("Okay. May I sit down now?");
        }
        if (q.contains("yes") == true) {
            Greenfoot.delay(10);
            sitDown();
            break;
        }
        if(q.contains("hard") == false && q.contains("yes") == false && q.contains("no") == false) {
          q=Greenfoot.ask("I don't understand the question. May I sit down?"); 
        }
    }
    }
         
        
    
    /**
     * This is a local method specific to the AkamaiWong class used to animate the character once the image is clicked on.
     * First, the image will enlarge to be 200 by 250 pixels, as opposed to its previous size of 100 by 125 pixels. 
     * Second, the two-dimensional array will a random rotation value for each coordinate within the given range. 
     *      (This random value is picked using Math.random (which picks a random number between 0 and 1)). 
     * Third, the character will move to a random location (the x and y values are set using Math.random). 
     *      As the character reaches each coordinate, the character will rotate to the specified rotation value for that coordinate stored in the 2D array. 
     * After the specified amount of repeats in the for loop, the character will rotate back to 0, and change to the sitting picture. 
     */
    public void actionClass(){
        
        GreenfootImage image = getImage();
        image.scale(200, 250);
        setImage(image);

        int[][] rotation = new int[9][5];
        for (int x=2;x<=8;x++){
         for (int y=2;y<=4;y++){
            rotation[x][y] = (int) (Math.random() * 360);
        } 
        }
  
        for (int i=0;i<20;i++){
            int x = (int) (Math.random() * 6) + 2;
            int y = (int) (Math.random() * 2) + 2;
            setLocation(x,y);
            turn(rotation[x][y]);
            Greenfoot.delay(10);
        }

        setRotation(0);
        Greenfoot.delay(20);
        returnToSeat();
           
    }
    
     public void myHobby(String s) {
         System.out.println(s);
}

}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The KevinLiu class is the model/object for my seating location.
 * 
 * @author Mr. Kaehms
 * @version 2.0 Aug 13, 2019
 */
public class KevinLiu extends Student implements SpecialInterestOrHobby
{
    
    /**
     * Constructor for the KevinLiu class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     * lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     */
    public KevinLiu(String f, String l, int r, int s)
    {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Sets row to 5 and seat to 4
     * Sets up images for the kevinliu object
     */
    public KevinLiu() {
        firstName="Kevin";
        lastName="Liu";
        myRow=5;
        mySeat=4;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
        numStudents++;
    }
    
     /**
     * Act - uses if/else statements to run through a series of methods. Calls the "teleport" custom animation and "answerQuestion" methods.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this))
        {
            if (sitting)
            {
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
                myHobby("I like to play soccer!");
                Greenfoot.delay(50);
                teleport();
            }
            else
            {
                answerQuestion();
                sitDown();
            }
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName()
    {
        System.out.println("My name is " + firstName + " " + lastName);
    }
    
    /**
     * This method allows the user to interact with the student through a question and answer interface.
     * If the user inputs a sentence with "hard", the code outputs a response. Similar question-respionse chains continue.
     * Otherwise, the interface continues to ask the same question.
     * A "flag" variable is used as an exit condition for the while loop, to continue on the the next question.
     * The questions work in similar ways.
     */
    public void answerQuestion()
    {
        boolean flag = true;
        String q=Greenfoot.ask("What would you like to know");
        while(flag)
        {
            if (q.contains("hard"))
            {
                q=Greenfoot.ask("I have difficulty understanding recursion, else-if, abstract classes, interfaces, and overloaded methods. What else would you like to know?");
                if (q.contains("recursion"))
                {
                    q=Greenfoot.ask("Recursion is hard because I have trouble understanding how Java manages data in recursive method. May I sit down?");
                    flag = false;
                }
                if (q.contains("else-if"))
                {
                    q=Greenfoot.ask("Else-if statements are hard because I don't really understand how Java runs through the chained else-if conditions. May I sit down?");
                    flag = false;
                }
                if (q.contains("abstract"))
                {
                    q=Greenfoot.ask("Abstract classes are hard because it is hard to remember the correct syntax to define/use an abstract class. May I sit down?");
                    flag = false;
                }
                if (q.contains("interfaces"))
                {
                    q=Greenfoot.ask("Interfaces are hard to because it is diffucult to remember how and why to create and use an interface. May I sit down?");
                    flag = false;
                }
                if (q.contains("overload"))
                {
                    q=Greenfoot.ask("I find overloaded methods challenging because they involve different kinds of data, and it gets confusing to deal with several versions of the same method. May I sit down?");
                    flag = false;
                }
            }
            else
            {
                q=Greenfoot.ask("I don't understand the question.. What would you like to know?");
            }
        }
        flag = true;
        while(flag)
        {
            if(q.equals("yes"))
            {
                flag = false;
            }
            else
            {
                q=Greenfoot.ask("May I please sit down?");
            }
        }
    }
    
    /**
     * The teleport method uses math.random to initialize a 2-d array (2x100 dimensions) with random integers from 0-10 in the first row, and 0-6 on the second row.
     * Each column of two integers represents an x&y coordinate, which the object iterates through and "teleports"
     * Finally, the object returns to the original location using the "returrnToSeat" method
     */
    public void teleport()
    {
        int path[][] = new int[2][100];
        for(int n = 0; n<path[0].length; n++)
        {
            path[0][n] = (int)(Math.random()*12);
        }
        for(int i = 0; i<path[1].length; i++)
        {
            path[1][i] = (int)(Math.random()*6);
        }
        for(int k = 0; k < path[0].length; k++)
        {
            setLocation(path[0][k], path[1][k]);
            Greenfoot.delay(1);
        }
        returnToSeat();
    }
    
    /**
     * Prints myHobby (method from Student class. to the console
     */
    public void myHobby(String s)
    {
        System.out.println(s);
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;

/**
 * Code for Keagan Wilson Class
 * spins
 * 
 * @author Keagan Wilson 
 * @version 2.0 9/11/19
 */
public class KeaganWilson extends Student implements SpecialInterestOrHobby, NumberOfSiblings
{
    /**
     * shows that I have no brothers
     */
    private int brothers = 0;
    /**
     * shows that I have no sisters
     */
    private int sisters = 0;
    /**
     * Constructor for the KeaganWilson class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * Adds to student count static variable
     */
    public KeaganWilson(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
        numStudents++; //count for students
    }
    /**
     * Default constructor, if you don't pass in a name and seating location
     * Pay attention to how the row and seat variables set the location of the image.  1,1 is the first cell in the upper left
     * of the classroom.
     */
    public KeaganWilson() {
        firstName="Keagan";
        lastName="Wilson";
        myRow=4;
        mySeat=6;
       // imgFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
       standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.jpg";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
    }
    
     /**
     * Act - do whatever the KeaganWilson actor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */   
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); // Print a blank line to create space between any student output.
                getName();
                sayName(soundFile);
            
                myHobby("I like to watch cool videos!");
            // Create a "special method for your class and put the call here.  You can twirl your image, resize it, move it around, change transparancy, or a 
            // combination of all of those types of actions, or more. Make sure to save the original image if you manipulate it, so that you can put it back.
            // Call the sitDown() method to move back  to your seat
            
                circleClass();  // Keagan Wilson's special method... Please write one of your own. You can use this, but please modify it and be creative.
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    
    /**
     * Prints the first and last name to the console
     */
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * This method needs to allow the user to interact with the student through a question and answer interface, and provide
     * some mechanism that allows the student to sit down once the Q&A session ends. It can answer consecutive questions (second level).
     * It contains the question about "what's hard?" but expands on that because the user can ask why a specific thing is hard and a reaon is provided
     * Also, they can ask how many siblings I have and some of my classes are listed
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know");
        if (q.contains("hard")){ //inside are level 2 questions
            q=Greenfoot.ask("Escape characters, truth tables, recursion, round-off error, and class type... What would you like information on?");
            if(q.contains("escape"))
                q=Greenfoot.ask("I sometimes can forget that backslash has special rules... May I sit down?");
            else if(q.contains("truth"))
                q=Greenfoot.ask("Truth tables can be tricky business sometimes... May I sit down?");
            else if(q.contains("recursion"))
                q=Greenfoot.ask("It takes a lot of thinking to understand what goes on when recursion is involved... May I sit down?");
            else if(q.contains("error"))
                q=Greenfoot.ask("Round-off error can trick me sometimes... May I sit down?");
            else if(q.contains("class"))
                q=Greenfoot.ask("Sometimes it can be hard to remember class types go by different rules than primative types... May I sit down?");
            else
                q=Greenfoot.ask("I don't understand the question... May I sit down?");
        }
        else if (q.contains("sibling")) {
            q=Greenfoot.ask("I have " + numberOfSiblings() + " siblings... May I sit down?");
        }
        else if(q.contains("classes")) {
            q=Greenfoot.ask("I'm in CSA, AP CAlC, AP Chem, and more... May I sit down?");
        }
        else if(q.contains("students")) {
            q=Greenfoot.ask("There are " + numStudents + " in this class... May I sit down?");
        }
        else {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
         if (q.equals("yes")){
            Greenfoot.delay(10);
            sitDown();
        }
        else
        answerQuestion();
        
    }
    /**
     * This is a local method specific to the KeaganWilson class used to animate the character once the image is clicked on. 
     * The object will bounce around and afterwards can answer questions.
     * Here a 2D array is used for movement with a changing x-value and a random y-value with the Math.Random function.
     * Uses a for loop to give values to the 2D array (with the length function used) and a while loop iterates through it.
     * The while loop is what allows the animation to appear
     */
    public void circleClass(){
        int time = 50;
        int count = 0;
        int flag = 0;
        int t = getX();
        int[][] movement = new int[50][2]; //2D array with time and values for x and y
        for(int i = 0; i < movement.length; i++) { //For loop to make the array and iterates through the length of the rows
            if (t < getWorld().getWidth() && flag == 0) { 
            t ++;
        }
        else if(t >= getWorld().getWidth() && flag == 0) {
            flag = 1;
            t --;
        }
        else if(t <= 0 && flag == 1) {
            movement[i][0] = t;
            flag = 0;
            t ++;
        }
        else if(t > 0 && flag == 1) {
            t --;
        }
        movement[i][0] = t;
        movement[i][1] = (int)(Math.random() * 10); //Math.random used for random y-coordinate
    }
        while(count < time) { //while loop that iterates through the array
            Greenfoot.delay(5);
            setLocation(movement[count][0], movement[count][1]); //value set equal to x and y from 2D array
            getImage().rotate((int)(Math.random() * 360)); //Math.random used for rotating image
            count++;
        }
        setImage(standingFile);
        returnToSeat();
    }
    /**
     * Prints out a fact about me
     */
     public void myHobby(String s) {
         System.out.println(s);
    }
    /**
     * returns my total number of siblings
     */
     public int numberOfSiblings() {
         return brothers + sisters;
    }
    /**
     * Returns my number of brothers
     */
     public int numberOfBrothers() {
         return brothers;
     }
    /**
     * Returns my number of sisters
     */
     public int numberOfSisters(){
         return sisters;
     }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * An object of the class Student. Represents an individual student.
 * 
 * @author Alan Liang
 * @version 09/02/19
 */
public class AlanLiang extends Student implements SpecialInterestOrHobby
{
     /**
     * Constructor for the AlanLiang class.
     * Constructors are special methods with the same exact name as the class name.  
     * Constructors to not have return types.
     * Constructors can be overloaded. This means we can call a constructor with different sets of parameter
     *  lists to initalize for different conditions (depending on what constructors have been written.
     * @param String f (firstname)
     * @param String l (lastname)
     * @param int r (row of seating arrangement)
     * @param int s (seat number within row seating arrangement)
     * 
     */
    public AlanLiang(String f, String l, int r, int s) {
        firstName=f;
        lastName=l;
        myRow=r;
        mySeat=s;
        portraitFile=f.toLowerCase()+l.toLowerCase()+".jpg";    // Make sure to name your image files firstlast.jpg, all lowercase!!!
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.png";
        soundFile=f.toLowerCase()+l.toLowerCase()+".wav";  // Make sure to name your sound files firstlast.wav, all lowercase!!!
        setImage(portraitFile);
        sitting=true;
        numStudents++;
        
    }
    public AlanLiang() {
        firstName="Alan";
        lastName="Liang";
        myRow=3;
        mySeat=2;
        portraitFile=firstName.toLowerCase()+ lastName.toLowerCase()+".jpg";
        standingFile=firstName.toLowerCase()+ lastName.toLowerCase()+"-standing.png";
        soundFile=firstName.toLowerCase()+ lastName.toLowerCase()+".wav";
        setImage(portraitFile);
        sitting=true;
        numStudents++;
       
    }  
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this)){
            if (sitting){
                sitting=false;
                setImage(standingFile);
                System.out.println(""); 
                getName();
                sayName(soundFile);
            
                myHobby("I like to play tennis!");
         
            
                animation();  
            }
            else {
                answerQuestion();
                sitDown();
            }
                    
        }
    } 
    public void getName(){
        System.out.println("My name is " + firstName + " " + lastName);
    }
    /**
     * If the user asks a question containing the phrase "summer homework," the prompt will reply with "2D arrays, Interface, Abstract Classes, Instance Variabls, and Classes." If the next question contains any of the 5 items in the list, the 
     * prompt will proceed to explain said item. Once finished, the prompt will request to sit down. If the question asked meets none of these demands, the prompt will reply with "I don't understand the question... May I sit down?" Once the 
     * prompt requests to sit down, any answer will end with the object sitting down.
     */
    public void answerQuestion(){
        String q=Greenfoot.ask("What would you like to know");
        if (q.contains("summer homework")){
            q=Greenfoot.ask("2D arrays, Interface, Abstract Classes, Instance Variables, and Classes.");
            if (q.contains("2D arrays")){
                q=Greenfoot.ask("2D arrays are arrays with both columns and rows, simply, an array of arrays... May I sit down?");
            }
            else if (q.contains("Interface")){
                q=Greenfoot.ask("Interface is the blueprint of a class. It has static and abstract methods... May I sit down?");
            }
            else if (q.contains("Abstract Classes")){
                q=Greenfoot.ask("Abstract Classes can't have objects of their own, rather other classes extend from the Abstract class... May I sit down?");
            }
            else if (q.contains("Instance Variables")){
                q=Greenfoot.ask("Instance variables create an object of a class... May I sit down?");
            }
            else if (q.contains("Classes")){
                q=Greenfoot.ask("Classes are a blueprint for any real life entity... May I sit down?");
            }    
        }
        else if (q.contains("How many students")){
            q=Greenfoot.ask(numStudents + "... May I sit down?");
        }
        else {
          q=Greenfoot.ask("I don't understand the question... May I sit down?"); 
        }
         if (q.equals("yes")){
            Greenfoot.delay(10);
            sitDown();
        }
        
    }
    /**
     * I used the 2D array to represent the Classroom's seats. The array is also used as a grid for the object to move around in. In the loops, the length of each column is found with the length property. The length of each row is found with
     * the length property of newArray[i]. 
     * <br><br>
     * The for-loop that iterates through the variable i iterates through each row. The for-loop that iterates through the variable j iterates through each column of each row. 
     * <br><br>
     * Math.random() is used to decide a random integer between 0 and the length of the array minus 1. It is used to decide at which row the object starts moving horizontally.
     * <br><br>
     * The object starts at the top left corner. It starts by going down a random amount, and then moving all the way across the array. Once it reaches the far right side of the array, it goes down the remaining amount, ending up in the bottom 
     * right corner.
     * <br><br>
     * 
     * 
     */
    public void animation(){
        int[][] newArray;
        newArray = new int[6][10];
        setLocation(0,0);
        Greenfoot.delay(10);
        int j = 0;
        int rowToTurn = (int)(Math.random()*newArray.length);
        System.out.println(rowToTurn);
        for (int i=0; i<(newArray.length); i++)
        {
            if (i == rowToTurn){
                for (j=0; j<(newArray[i].length); j++)
                {
                    //System.out.println(i+" "+j);
                    setLocation(j, i);
                    Greenfoot.delay(20);
                }
            }
            else{
                setLocation(j, i);
                Greenfoot.delay(20);
            }
        }
           
           returnToSeat();
    }
     public void myHobby(String s) {
         System.out.println(s);
}

}